IPUNGG STORE WEB — Node.js 18 sampai 24

Prasyarat:
- Node.js 18, 20, 22, atau 24
- npm yang sesuai dengan versi Node.js

Jalankan:
1. Ekstrak arsip ke folder project.
2. Masuk ke folder yang berisi package.json dan server.js.
3. Jalankan: npm ci
4. Jalankan: npm start

Port:
Aplikasi memakai SERVER_PORT, lalu PORT, dan default 3000.

Data:
Database disimpan di data/db.json secara default. Backup file ini sebelum
mengganti project atau melakukan deploy ulang. Folder public/uploads juga
menyimpan gambar/audio yang diunggah.

Catatan kompatibilitas:
Batas engines sudah diubah menjadi >=18 <25. Ini menyatakan rentang versi
yang ditargetkan, bukan bukti bahwa seluruh alur bisnis sudah diuji pada
setiap versi Node. Uji login admin, order, pembayaran, upload, dan koneksi bot
setelah instalasi. Node.js 18 sudah tidak didukung upstream; untuk server
produksi, utamakan Node.js 22 atau 24 bila environment mengizinkan.
