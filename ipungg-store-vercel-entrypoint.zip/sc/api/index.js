// Vercel serverless entry point for IPUNGG STORE.
// NOTE: filesystem-backed db/uploads are ephemeral on Vercel; persistent storage adapter is still required.
process.env.STORE_DATA_DIR = process.env.STORE_DATA_DIR || '/tmp/ipungg-store-data';
const fs = require('fs');
fs.mkdirSync(process.env.STORE_DATA_DIR, { recursive: true });
const { createApp } = require('../server');
const app = createApp({ botOnly: false });
module.exports = app;
