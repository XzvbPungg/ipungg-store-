/*
 * IPUNGG STORE — server.js (1 file lengkap, tidak butuh folder lib/)
 * Kebutuhan: express, axios (qrcode opsional). Folder public/ tetap dipakai.
 *
 * ISI DI SINI jika web & bot beda server (atau pakai Custom Environment Variables):
 */
const CONFIG = {
  BOT_URL: '',        // contoh: 'http://domainpanel:PORT'  (kosong = bot satu server dengan web)
  BOT_API_KEY: '',    // harus sama persis dengan BOT_API_KEY di server bot
  OWNER_NUMBER: '',   // contoh: '6282125774233' (notifikasi pesanan masuk)
  PORT: '',           // kosongkan: otomatis pakai SERVER_PORT / PORT panel
};
for (const k of Object.keys(CONFIG)) if (CONFIG[k] && !process.env[k]) process.env[k] = String(CONFIG[k]);

const __realRequire = require;
const __defs = {};
const __cache = {};
function __req(n) {
  const m = /^\.\/(?:lib\/)?([a-z]+)$/.exec(n);
  if (m && __defs[m[1]]) {
    if (!__cache[m[1]]) { const mod = { exports: {} }; __cache[m[1]] = mod; __defs[m[1]](mod, mod.exports, __req); }
    return __cache[m[1]].exports;
  }
  return __realRequire(n);
}

__defs['util'] = function (module, exports, require) {
const crypto = require('crypto');

const clean = (v, max = 200) =>
  String(v ?? '').replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max);

const cleanMultiline = (v, max = 500) =>
  String(v ?? '').replace(/[\u0000-\u0009\u000b-\u001f\u007f]/g, '').trim().slice(0, max);

// 08xxx / +62xxx / 62xxx -> 62xxx
function normPhone(v) {
  let n = String(v ?? '').replace(/[^0-9]/g, '');
  if (n.startsWith('0')) n = '62' + n.slice(1);
  else if (n.startsWith('8')) n = '62' + n;
  return n;
}
const validPhone = (n) => /^[1-9][0-9]{8,14}$/.test(n);

const GROUP_RE = /^https:\/\/chat\.whatsapp\.com\/[A-Za-z0-9_-]{10,40}(\?[^\s]*)?$/;
const validGroupLink = (l) => GROUP_RE.test(l);
const inviteCode = (l) => String(l).split('chat.whatsapp.com/')[1].split(/[?#]/)[0];

const newId = (bytes = 8) => crypto.randomBytes(bytes).toString('hex');
const rupiah = (n) => 'Rp' + Number(n || 0).toLocaleString('id-ID');
const maskPhone = (p) => (p && p.length > 6 ? p.slice(0, 4) + '****' + p.slice(-3) : p);

const esc = (s) =>
  String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const dig = (obj, p) => {
  if (!p) return undefined;
  return String(p).split('.').reduce((o, k) => (o == null ? undefined : o[k]), obj);
};

const validUrl = (u) => {
  try { const x = new URL(u); return x.protocol === 'https:' || x.protocol === 'http:'; } catch { return false; }
};

module.exports = { clean, cleanMultiline, normPhone, validPhone, validGroupLink, inviteCode, newId, rupiah, maskPhone, esc, dig, validUrl };

};

__defs['db'] = function (module, exports, require) {
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DIR = process.env.STORE_DATA_DIR || path.join(__dirname, 'data');
const FILE = path.join(DIR, 'db.json');

function hashPassword(pw, salt = crypto.randomBytes(16).toString('hex')) {
  const h = crypto.scryptSync(String(pw), salt, 64).toString('hex');
  return `${salt}:${h}`;
}
function verifyPassword(pw, stored) {
  try {
    const [salt, h] = String(stored).split(':');
    const x = crypto.scryptSync(String(pw), salt, 64);
    const y = Buffer.from(h, 'hex');
    return x.length === y.length && crypto.timingSafeEqual(x, y);
  } catch { return false; }
}

// Sesuai dokumentasi https://www.austinx.cloud/api-docs
const AUSTIN = {
  baseUrl: 'https://www.austinx.cloud',
  createPath: '/api/deposit/create',
  statusPath: '/api/deposit/check/{id}',
  method: 'POST', statusMethod: 'GET',
  authMode: 'query', keyField: 'apikey',
  bodyFormat: 'json', amountField: 'amount', refField: '',
  map: { trxId: 'deposit.transaction_id', qrImage: 'deposit.qr_image', qrString: 'deposit.qr_string', payUrl: '', expired: 'deposit.expired_at', status: 'status', payAmount: 'deposit.amount' },
  paidValues: 'paid', expiredValues: 'expired,cancel,failed',
};
function applyAustin(p) {
  const keep = { apikey: p.apikey || '', apiSecret: p.apiSecret || '' };
  Object.assign(p, JSON.parse(JSON.stringify(AUSTIN)), keep);
}

function defaults() {
  const pass = process.env.ADMIN_PASS || crypto.randomBytes(5).toString('hex');
  const user = process.env.ADMIN_USER || 'admin';
  if (process.env.WEB_MODE !== 'bot') {
    console.log('\n[ipungg-store] Akun admin pertama dibuat');
    console.log(`[ipungg-store] Username : ${user}`);
    console.log(`[ipungg-store] Password : ${pass}   <- segera ganti di dashboard (menu Akun)\n`);
  }
  return {
    settings: {
      siteName: 'Ipungg Store',
      logo: '',
      thumbnail: '',
      whatsapp: '',
      telegram: '',
      telegramBackupToken: '',
      telegramBackupChatId: '',
      channelId: '',
      channelLink: '',
      publicUrl: '',
      maintenance: false,
      botApiKey: crypto.randomBytes(20).toString('hex'),
      sessionSecret: crypto.randomBytes(32).toString('hex'),
      orderTtlMinutes: 15,
      payment: Object.assign({ apikey: '', apiSecret: '' }, JSON.parse(JSON.stringify(AUSTIN))),
    },
    plans: [
      { id: 'sewa-1b', name: '1 Bulan', days: 30, price: 15000 },
      { id: 'sewa-2b', name: '2 Bulan', days: 60, price: 25000 },
      { id: 'sewa-3b', name: '3 Bulan', days: 90, price: 35000 },
      { id: 'sewa-4b', name: '4 Bulan', days: 120, price: 45000 },
      { id: 'sewa-1t', name: '1 Tahun', days: 365, price: 60000 },
    ],
    products: [],
    categories: [],
    orders: [],
    admin: { user, hash: hashPassword(pass) },
  };
}

let data = null;

function load() {
  fs.mkdirSync(DIR, { recursive: true });
  if (fs.existsSync(FILE)) {
    try { data = JSON.parse(fs.readFileSync(FILE, 'utf8')); }
    catch (e) {
      fs.copyFileSync(FILE, FILE + '.corrupt-' + Date.now());
      console.error('[ipungg-store] db.json rusak, dibuat baru (file lama disimpan .corrupt)');
      data = defaults();
    }
  } else {
    data = defaults();
  }
  // merge field baru supaya update aman
  data.settings = data.settings || {};
  if (data.settings.telegramBackupToken === undefined) data.settings.telegramBackupToken = '';
  if (data.settings.telegramBackupChatId === undefined) data.settings.telegramBackupChatId = '';
  data.settings.payment = Object.assign({}, data.settings.payment || {});
  const pp = data.settings.payment;
  // tebakan awal yang salah (/api/create) diganti otomatis dengan alamat resmi AustinPay
  if (pp.createPath === '/api/create' && pp.statusPath === '/api/status') applyAustin(pp);
  pp.map = Object.assign({}, AUSTIN.map, pp.map || {});
  for (const k of ['plans', 'products', 'orders', 'categories']) if (!Array.isArray(data[k])) data[k] = [];
  save();
  return data;
}

function save() {
  const tmp = FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
  fs.renameSync(tmp, FILE);
}

function get() { return data || load(); }

module.exports = { get, load, save, hashPassword, verifyPassword, applyAustin, DIR };

};

__defs['auth'] = function (module, exports, require) {
const crypto = require('crypto');
const db = require('./db');

const COOKIE = 'ip_sess';
const TTL = 12 * 60 * 60 * 1000;

const b64 = (b) => Buffer.from(b).toString('base64url');
const sign = (p) => crypto.createHmac('sha256', db.get().settings.sessionSecret).update(p).digest('base64url');

function issue(user) {
  const payload = b64(JSON.stringify({ u: user, exp: Date.now() + TTL }));
  return `${payload}.${sign(payload)}`;
}

function parseCookies(req) {
  const out = {};
  String(req.headers.cookie || '').split(';').forEach((p) => {
    const i = p.indexOf('=');
    if (i > 0) out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim());
  });
  return out;
}

function verify(token) {
  if (!token || !token.includes('.')) return null;
  const [payload, sig] = token.split('.');
  const exp = sign(payload);
  const a = Buffer.from(sig), b = Buffer.from(exp);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try {
    const d = JSON.parse(Buffer.from(payload, 'base64url').toString());
    if (d.exp < Date.now()) return null;
    return d;
  } catch { return null; }
}

function setCookie(res, token, req) {
  const secure = req.secure || req.headers['x-forwarded-proto'] === 'https';
  res.setHeader('Set-Cookie',
    `${COOKIE}=${encodeURIComponent(token)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${TTL / 1000}${secure ? '; Secure' : ''}`);
}
const clearCookie = (res) => res.setHeader('Set-Cookie', `${COOKIE}=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0`);

function requireAdmin(req, res, next) {
  const s = verify(parseCookies(req)[COOKIE]);
  if (!s || s.u !== db.get().admin.user) return res.status(401).json({ ok: false, error: 'Belum login' });
  // mutasi hanya lewat JSON (mitigasi CSRF form lintas situs)
  if (!['GET', 'HEAD'].includes(req.method) && !/application\/json|^audio\//i.test(String(req.headers['content-type'] || '')))
    return res.status(415).json({ ok: false, error: 'Content-Type harus application/json' });
  next();
}

function requireBot(req, res, next) {
  const key = String(req.headers['x-api-key'] || '');
  const real = process.env.BOT_API_KEY || db.get().settings.botApiKey || '';
  const a = Buffer.from(key), b = Buffer.from(real);
  if (!real || real === 'GANTI_DENGAN_KUNCI_RAHASIA' || a.length !== b.length || !crypto.timingSafeEqual(a, b))
    return res.status(401).json({ ok: false, error: 'API key bot salah' });
  next();
}

// rate limit sederhana per IP
const buckets = new Map();
function limit(name, max, windowMs) {
  return (req, res, next) => {
    const k = name + ':' + (req.ip || '');
    const now = Date.now();
    const arr = (buckets.get(k) || []).filter((t) => now - t < windowMs);
    if (arr.length >= max) return res.status(429).json({ ok: false, error: 'Terlalu banyak percobaan, coba lagi nanti' });
    arr.push(now); buckets.set(k, arr);
    next();
  };
}
setInterval(() => { const n = Date.now(); for (const [k, v] of buckets) if (!v.some((t) => n - t < 3600e3)) buckets.delete(k); }, 600e3).unref();

module.exports = { issue, verify, parseCookies, setCookie, clearCookie, requireAdmin, requireBot, limit, COOKIE };

};

__defs['payment'] = function (module, exports, require) {
// Adapter payment gateway. Default = AustinPay (https://www.austinx.cloud/api-docs).
// Semua endpoint & nama field bisa diubah dari Dashboard > API key tanpa edit kode.
const axios = require('axios');
const crypto = require('crypto');
const db = require('./db');
const { dig } = require('./util');

const split = (s) => String(s || '').split(',').map((x) => x.trim().toLowerCase()).filter(Boolean);

// pembeli hanya melihat pesan umum; detail teknis untuk admin (dashboard + console)
class PayError extends Error {
  constructor(detail) { super(detail); this.public = 'Pembayaran sedang bermasalah. Coba lagi sebentar lagi atau hubungi admin.'; }
}
class BusyError extends Error {
  constructor() { super('Batas pembuatan QR per menit tercapai'); this.public = 'Sedang banyak pesanan. Coba lagi dalam 1 menit.'; }
}
let lastError = null;
const fail = (detail) => { lastError = { at: Date.now(), msg: detail }; return new PayError(detail); };
const getLastError = () => lastError;

// AustinPay membatasi 5 pembuatan QR / menit per API key -> kita jaga di 4 supaya aman
const gate = [];
function rateGate() {
  const now = Date.now();
  while (gate.length && now - gate[0] > 60000) gate.shift();
  if (gate.length >= 4) throw new BusyError();
  gate.push(now);
}

function build(p, path, payload, method) {
  const m = String(method || p.method || 'POST').toUpperCase();
  const url = p.baseUrl.replace(/\/+$/, '') + path;
  const headers = {};
  const params = {};
  const body = { ...payload };
  const secret = p.apiSecret || '';
  const mode = secret ? 'header' : (p.authMode || 'query'); // HMAC mewajibkan key lewat header
  const kf = p.keyField || 'apikey';
  if (mode === 'header') headers[kf === 'apikey' ? 'X-API-Key' : kf] = p.apikey;
  else if (mode === 'bearer') headers.Authorization = `Bearer ${p.apikey}`;
  else if (mode === 'query' || m === 'GET') params[kf] = p.apikey;
  else body[kf] = p.apikey;

  const cfg = { url, method: m, headers, timeout: 20000, validateStatus: () => true };
  let raw = '';
  if (m === 'GET') Object.assign(params, body);
  else if (p.bodyFormat === 'form') { raw = new URLSearchParams(body).toString(); headers['Content-Type'] = 'application/x-www-form-urlencoded'; cfg.data = raw; }
  else { raw = JSON.stringify(body); headers['Content-Type'] = 'application/json'; cfg.data = raw; }
  if (Object.keys(params).length) cfg.params = params;

  if (secret) { // tanda tangan HMAC-SHA256: METHOD \n PATH \n BODY \n TIMESTAMP
    const ts = Date.now().toString();
    headers['X-Timestamp'] = ts;
    headers['X-Signature'] = crypto.createHmac('sha256', secret).update(`${m}\n${new URL(url).pathname}\n${raw}\n${ts}`).digest('hex');
  }
  return cfg;
}

function extract(p, data) {
  const m = p.map || {};
  return {
    trxId: dig(data, m.trxId), qrImage: dig(data, m.qrImage), qrString: dig(data, m.qrString),
    payUrl: dig(data, m.payUrl), expiredAt: dig(data, m.expired), payAmount: dig(data, m.payAmount),
  };
}

function explain(res, method, path) {
  const d = res.data && typeof res.data === 'object' ? res.data : null;
  const msg = d && d.message ? String(d.message).slice(0, 160) : '';
  const s = res.status;
  const why = s === 404 ? 'Alamat / path salah.'
    : s === 401 ? 'API key salah atau tidak terkirim.'
    : s === 403 ? 'IP server ini belum didaftarkan di AustinPay (Profil > Whitelist IP), atau akun dibekukan.'
    : s === 429 ? 'Terlalu banyak request (batas 5 QR per menit).'
    : s === 400 ? 'Parameter ditolak (cek nominal minimal deposit).' : '';
  return `Gateway menjawab ${s} untuk ${method} ${path}${msg ? ` — "${msg}"` : ''}. ${why}`.trim();
}

async function createCharge(order) {
  const p = db.get().settings.payment;
  if (!p.apikey) throw fail('API key payment gateway belum diisi (Dashboard > API key).');
  rateGate();
  const payload = { [p.amountField || 'amount']: order.amount };
  if (p.refField) payload[p.refField] = order.id;
  const cfg = build(p, p.createPath, payload, p.method);
  let res;
  try { res = await axios(cfg); }
  catch (e) { throw fail(`Tidak bisa terhubung ke gateway (${e.code || e.message}). Cek Base URL.`); }
  const d = res.data;
  if (res.status >= 400 || (d && typeof d === 'object' && d.success === false))
    throw fail(explain(res, cfg.method, p.createPath) + ' Pakai tombol "Tes buat transaksi" di Dashboard > API key.');
  const out = extract(p, d);
  if (!out.qrImage && !out.qrString && !out.payUrl)
    throw fail('Respon gateway diterima tapi tidak berisi QR / link bayar. Cek "Lokasi data di respon gateway" (pakai tombol Tes).');
  out.payAmount = Number(out.payAmount) > 0 ? Number(out.payAmount) : 0;
  lastError = null;
  return out;
}

async function checkStatus(order) {
  const p = db.get().settings.payment;
  if (!p.apikey || !order.trxId) return 'pending';
  const tpl = p.statusPath || '';
  let path = tpl; const payload = {};
  if (tpl.includes('{id}')) path = tpl.split('{id}').join(encodeURIComponent(order.trxId));
  else { if (p.refField) payload[p.refField] = order.id; payload.id = order.trxId; payload.amount = order.amount; }
  const cfg = build(p, path, payload, p.statusMethod || p.method);
  const res = await axios(cfg);
  const d = res.data;
  if (res.status >= 400 || (d && typeof d === 'object' && d.success === false)) {
    fail('Cek status gagal. ' + explain(res, cfg.method, tpl) + ' Pesanan tidak terdeteksi lunas sebelum ini beres.');
    return 'pending';
  }
  const raw = String(dig(d, (p.map || {}).status) ?? '').toLowerCase();
  if (split(p.paidValues).includes(raw)) return 'paid';
  if (split(p.expiredValues).includes(raw)) return 'expired';
  return 'pending';
}

// IP publik server ini (untuk didaftarkan di Whitelist IP AustinPay)
async function egressIp() {
  try {
    const r = await axios({ url: 'https://api.ipify.org?format=json', timeout: 6000, validateStatus: () => true });
    return (r.data && r.data.ip) || '';
  } catch { return ''; }
}

// Alat uji untuk admin: membuat 1 QR sungguhan (kedaluwarsa sendiri) dan melaporkan apa adanya
async function testCreate() {
  const d0 = db.get(); const p = d0.settings.payment;
  if (!p.apikey) return { good: false, hint: 'API key payment belum diisi. Isi dan simpan dulu.' };
  try { rateGate(); } catch { return { good: false, hint: 'Batas 5 pembuatan QR per menit dari gateway tercapai. Tunggu 1 menit lalu tes lagi.' }; }
  const amt = Math.min(...d0.plans.map((x) => x.price).filter(Boolean)) || 10000;
  const payload = { [p.amountField || 'amount']: amt };
  if (p.refField) payload[p.refField] = 'TEST' + Date.now().toString(36).toUpperCase();
  const cfg = build(p, p.createPath, payload, p.method);
  const mask = (t) => String(t).split(p.apikey).join('••••');
  const qs = cfg.params ? '?' + new URLSearchParams(cfg.params) : '';
  const out = { good: false, amount: amt, method: cfg.method, url: mask(cfg.url + qs) };
  let res;
  try { res = await axios(cfg); }
  catch (e) { return { ...out, error: e.code || e.message, hint: `Tidak bisa terhubung ke ${p.baseUrl}. Cek "Base URL" (salah ketik, atau domain gateway berbeda).` }; }
  out.status = res.status;
  const raw = typeof res.data === 'string' ? res.data : JSON.stringify(res.data, null, 2);
  out.body = mask(raw ?? '').slice(0, 1500);
  const f = extract(p, res.data); out.found = {};
  for (const k of Object.keys(f)) out.found[k] = f[k] == null || f[k] === '' ? null : String(f[k]).slice(0, 80);
  const got = f.qrImage || f.qrString || f.payUrl;
  const s = res.status;
  const msg = res.data && typeof res.data === 'object' && res.data.message ? String(res.data.message) : '';
  const soft = res.data && typeof res.data === 'object' && res.data.success === false;
  if (s === 404) out.hint = 'Alamat tidak ditemukan (404). "Base URL" atau "Path buat transaksi" salah. Samakan persis dengan dokumentasi gateway.';
  else if (s === 401) out.hint = 'API key ditolak (401). Periksa API key; kalau kamu sudah membuat API Secret di AustinPay, isi juga "API Secret" di sini.';
  else if (s === 403 || /whitelist/i.test(msg)) out.hint = 'Ditolak (403): IP server ini belum didaftarkan di AustinPay. Buka austinx.cloud/profile > Whitelist IP, lalu tambahkan IP di bawah.';
  else if (s === 405) out.hint = 'Method salah (405). Coba ganti POST / GET.';
  else if (s === 429) out.hint = 'Terlalu banyak request (429). Tunggu 1 menit.';
  else if (s >= 500) out.hint = `Error di sisi gateway (${s}). Coba lagi nanti atau hubungi pihak gateway.`;
  else if (s >= 400 || soft) out.hint = `Permintaan ditolak${msg ? `: "${msg}"` : ` (${s})`}. Lihat isi respon di bawah.`;
  else if (got) { out.hint = 'Berhasil. QR ditemukan, pembayaran siap dipakai. (QR uji ini kedaluwarsa sendiri.)'; out.good = true; }
  else out.hint = 'Respon diterima tapi lokasi data QR belum cocok. Lihat isi respon di bawah, lalu isi "Lokasi data di respon gateway" sesuai isinya.';
  if (s === 401 || s === 403 || /whitelist/i.test(msg)) out.egressIp = await egressIp();
  return out;
}

module.exports = { createCharge, checkStatus, testCreate, egressIp, getLastError, PayError, BusyError, _resetGate: () => { gate.length = 0; } };

};

__defs['bridge'] = function (module, exports, require) {
// Penghubung ke bot.
// Mode lokal : web satu proses dengan bot (socket langsung).
// Mode remote: web di server lain, memanggil bot lewat API (BOT_URL + BOT_API_KEY).
const fs = require('fs');
const crypto = require('crypto');
const path = require('path');
const axios = require('axios');
const db = require('./db');
const { inviteCode } = require('./util');

let sock = null;
const setSocket = (s) => { sock = s; };
// socket dari start()/plugin; cadangannya global.socket yang diisi bot setiap ada pesan
const S = () => sock || global.socket || null;
const localReady = () => { const s = S(); return !!(s && s.user); };

const root = process.env.BOT_ROOT || process.cwd();
const sewaPath = path.join(root, 'library/database/sewagrup.json');
const notifPath = path.join(root, 'library/database/sewa_notified.json');
const readJson = (f, fb) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return fb; } };
const writeJson = (f, d) => { fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, JSON.stringify(d, null, 2)); };

// ---- remote ----
const pluginLinked = () => typeof lastPoll === 'number' && lastPoll > 0 && (Date.now() - lastPoll < 20000);
// Jika bot sudah aktif melakukan polling ipungg-link, otomatis prioritaskan
// mode plugin walaupun setting BOT_URL lama masih tersimpan di dashboard.
const remoteUrl = () => {
  if (pluginLinked()) return '';
  return String(process.env.BOT_URL || db.get().settings.botUrl || '').replace(/\/+$/, '');
};
const apiKey = () => process.env.BOT_API_KEY || db.get().settings.botApiKey || '';
let remoteOnline = false, pinger = null;

async function call(method, p, data) {
  let r;
  try {
    r = await axios({ method, url: remoteUrl() + p, data, headers: { 'x-api-key': apiKey() }, timeout: 45000, validateStatus: () => true });
  } catch (e) { throw new Error('Server bot tidak terjangkau (cek URL bot & port)'); }
  if (r.status === 401) throw new Error('API key bot tidak cocok dengan server bot');
  if (!r.data || r.data.ok !== true) throw new Error((r.data && r.data.error) || `Server bot error (${r.status})`);
  return r.data;
}
// cek koneksi ke server bot + sebut penyebab kalau gagal
let last = { state: 'nourl', msg: 'Belum dicek' };
async function probe() {
  const u = remoteUrl();
  if (!u && !S() && process.env.WEB_MODE !== 'full') { // mode sambung otomatis (plugin ipungg-link di server bot)
    const age = Date.now() - lastPoll;
    if (lastPoll && age < 20000) last = lastInfo.online === false
      ? { state: 'offline', msg: 'Plugin bot sudah nyambung ke toko, tapi WhatsApp bot belum login/terhubung. Cek Console server bot.', version: lastInfo.version || '' }
      : { state: 'online', msg: 'Bot terhubung ke toko (sambung otomatis).', version: lastInfo.version || '' };
    else last = { state: 'offline', msg: lastPoll ? `Bot terakhir menghubungi toko ${Math.round(age / 1000)} detik lalu. Cek bot menyala dan plugin ipungg-link terpasang.` : 'Bot belum pernah menghubungi toko. Di server bot pasang plugin ipungg-link, lalu kirim perintah .sambungweb KODE ke bot (kode dibuat di Dashboard > API key > Sambungkan bot).' };
    remoteOnline = false; return last;
  }
  if (!u) {
    last = localReady() ? { state: 'online', msg: 'Bot terhubung (satu server dengan web).' }
      : { state: 'offline', msg: 'Mode satu server: WhatsApp bot belum terhubung. Cek Console server ini.' };
    remoteOnline = false; return last;
  }
  let r;
  try { r = await axios({ method: 'get', url: u + '/api/bot/ping', headers: { 'x-api-key': apiKey() }, timeout: 8000, validateStatus: () => true }); }
  catch (e) {
    remoteOnline = false;
    return (last = { state: 'unreachable', msg: `Server bot tidak terjangkau (${e.code || e.message}). Cek alamat & port di BOT_URL, dan pastikan server bot menyala.` });
  }
  const d = r.data;
  const ver = d && typeof d === 'object' ? d.version : undefined;
  if (r.status === 401) last = { state: 'key', msg: 'API key tidak cocok. BOT_API_KEY di server web harus sama persis dengan di server bot.' };
  else if (!d || typeof d !== 'object' || r.status === 404) last = { state: 'http', msg: `Alamat itu bukan server bot (status ${r.status}). Pastikan port milik server bot dan web/server.js di server bot sudah versi terbaru.` };
  else if (d.ok && d.online) last = { state: 'online', msg: 'Bot terhubung.' };
  else if (d.ok) last = { state: 'offline', msg: d.hasSocket ? 'Server bot menyala tapi WhatsApp belum login/terhubung. Cek Console server bot (pairing / sesi).' : 'Server bot menyala tapi belum menerima koneksi WhatsApp. Pastikan handler.js di server bot sudah versi baru, lalu restart server bot.' };
  else last = { state: 'http', msg: d.error || `Respon tidak dikenal (${r.status})` };
  last.version = ver || '';
  remoteOnline = last.state === 'online';
  return last;
}
const ping = () => probe().catch(() => { remoteOnline = false; });
function startPinger() { if (pinger) return; pinger = setInterval(ping, 15000); pinger.unref(); ping(); }

// ---- sambung otomatis: toko menaruh pekerjaan di antrian, plugin di server bot menjemputnya ----
const jobs = [];
const waiting = new Map();
let lastPoll = 0, lastInfo = {};
const pullReady = () => Date.now() - lastPoll < 20000 && lastInfo.online !== false;
function enqueue(kind, payload, wait) {
  const id = crypto.randomBytes(6).toString('hex');
  jobs.push({ id, kind, payload, at: Date.now(), taken: false });
  if (jobs.length > 200) jobs.splice(0, jobs.length - 200);
  if (!wait) return Promise.resolve(id);
  return new Promise((resolve, reject) => {
    const ms = Number(process.env.LINK_JOB_TIMEOUT_MS) || 90000;
    const timer = setTimeout(() => {
      waiting.delete(id); const i = jobs.findIndex((j) => j.id === id); if (i >= 0) jobs.splice(i, 1);
      reject(new Error('Bot tidak merespon. Pastikan bot menyala dan plugin ipungg-link terpasang.'));
    }, ms);
    waiting.set(id, { resolve, reject, timer });
  });
}
function takeJobs(info) { // dipanggil plugin bot tiap beberapa detik (sekaligus tanda "bot hidup")
  lastPoll = Date.now(); lastInfo = info && typeof info === 'object' ? info : {};
  const out = [];
  for (let i = 0; i < jobs.length; i++) {
    const j = jobs[i];
    if (j.taken) continue;
    if (j.kind === 'send' && Date.now() - j.at > 15 * 60000) { jobs.splice(i--, 1); continue; }
    j.taken = true; out.push({ id: j.id, kind: j.kind, payload: j.payload });
    if (j.kind === 'send') jobs.splice(i--, 1);
  }
  return out;
}
function finishJob(id, success, data) {
  const w = waiting.get(id); if (!w) return false;
  clearTimeout(w.timer); waiting.delete(id);
  const i = jobs.findIndex((j) => j.id === id); if (i >= 0) jobs.splice(i, 1);
  if (success) w.resolve(data); else w.reject(new Error(String(data || 'Gagal di sisi bot').slice(0, 200)));
  return true;
}

const ready = () => (remoteUrl() ? remoteOnline : (S() || process.env.WEB_MODE === 'full') ? localReady() : pullReady());

// ---- lokal: meniru .addsewagc milik owner ----
async function addSewaLocal({ link, days }) {
  const sock = S();
  if (!localReady()) throw new Error('Bot belum terhubung');
  const code = inviteCode(link);
  let groupId, joinStatus;
  try { groupId = await sock.groupAcceptInvite(code); joinStatus = 'joined'; }
  catch (e) {
    try {
      const meta = await sock.groupGetInviteInfo(code);
      groupId = meta.id;
      // bot sudah ada di grup (mis. perpanjangan sewa) -> metadata bisa dibaca; kalau belum, WhatsApp menolak
      try { await sock.groupMetadata(groupId); joinStatus = 'joined'; } catch { joinStatus = 'pending'; }
    } catch (e2) { throw new Error('Link grup tidak valid / sudah kedaluwarsa'); }
  }
  let groupName = 'Unknown Group';
  try { groupName = (await sock.groupMetadata(groupId)).subject; } catch {}

  const list = readJson(sewaPath, []);
  const now = Date.now(), add = days * 86400000;
  const ex = list.find((v) => v.jid === groupId);
  let expired, renewed = false;
  if (ex) { renewed = true; ex.expired = ex.expired > now ? ex.expired + add : now + add; ex.warningSent = false; expired = ex.expired; }
  else { expired = now + add; list.push({ jid: groupId, expired, warningSent: false }); }
  writeJson(sewaPath, list);

  const notified = readJson(notifPath, {});
  if (notified[groupId]) { delete notified[groupId]; writeJson(notifPath, notified); }
  return { groupId, groupName, expired, renewed, joinStatus };
}
async function sendLocal(phone, text) {
  const sock = S();
  if (!localReady()) return false;
  try { await sock.sendMessage(`${phone}@s.whatsapp.net`, { text }); return true; } catch { return false; }
}

// ---- dipakai orders.js ----
async function addSewa(o) {
  if (remoteUrl()) { const d = await call('post', '/api/bot/addsewa', o); return d.result; }
  if (S() || process.env.WEB_MODE === 'full') return addSewaLocal(o);
  if (!pullReady()) throw new Error('Bot belum terhubung ke toko (plugin ipungg-link belum aktif / bot offline).');
  return enqueue('addsewa', { link: o.link, days: o.days, key: o.key }, true);
}
async function sendText(phone, text) {
  if (remoteUrl()) { try { await call('post', '/api/bot/send', { phone, text }); return true; } catch { return false; } }
  if (S() || process.env.WEB_MODE === 'full') return sendLocal(phone, text);
  await enqueue('send', { phone, text }, false); return true;
}

// ---------- Telegram backup tiap 1 jam ----------
let backupTimer = null;
let backupBusy = false;
function backupSettings() {
  const s = db.get().settings || {};
  return { token: String(s.telegramBackupToken || '').trim(), chatId: String(s.telegramBackupChatId || '').trim() };
}
async function telegramBackup(force = false) {
  if (backupBusy) return { ok: false, error: 'Backup sedang berjalan' };
  const { token, chatId } = backupSettings();
  if (!token || !chatId) return { ok: false, skipped: true, error: 'Token Telegram dan Chat ID belum diisi' };
  backupBusy = true;
  try {
    const d = db.get();
    // bridge module is isolated from the main app scope, so read the visitor map via globalThis.
    const visitorMap = globalThis.__ipunggLiveVisitors instanceof Map ? globalThis.__ipunggLiveVisitors : new Map();
    const active = [...visitorMap.entries()].filter(([,v]) => Date.now() - v.last < 90000).map(([id,v]) => ({ id, last: v.last, path: v.path }));
    const payload = {
      backupAt: new Date().toISOString(),
      site: { name: d.settings.siteName, publicUrl: d.settings.publicUrl || '' },
      visitorInfo: { online: active.length, snapshot: active },
      plans: d.plans,
      categories: d.categories,
      products: d.products,
      orders: d.orders,
      settings: { ...d.settings, telegramBackupToken: d.settings.telegramBackupToken ? '[SET]' : '', payment: { ...d.settings.payment, apikey: d.settings.payment?.apikey ? '[SET]' : '', apiSecret: d.settings.payment?.apiSecret ? '[SET]' : '' }, botApiKey: d.settings.botApiKey ? '[SET]' : '', sessionSecret: '[HIDDEN]' },
      note: 'Backup otomatis IPUNGG STORE. Token Telegram tidak disertakan dalam backup.'
    };
    const buf = Buffer.from(JSON.stringify(payload, null, 2), 'utf8');
    const form = new FormData();
    form.append('chat_id', chatId);
    form.append('caption', `📦 BACKUP IPUNGG STORE\n🕒 ${new Date().toLocaleString('id-ID')}\n👥 Pengunjung aktif: ${active.length}\n🧾 Total order: ${d.orders.length}`);
    form.append('document', new Blob([buf], { type: 'application/json' }), `ipungg-backup-${new Date().toISOString().replace(/[:.]/g,'-')}.json`);
    const r = await fetch(`https://api.telegram.org/bot${encodeURIComponent(token)}/sendDocument`, { method: 'POST', body: form });
    const j = await r.json().catch(() => ({}));
    if (!r.ok || !j.ok) throw new Error(j.description || `Telegram HTTP ${r.status}`);
    console.log('[ipungg-store] backup Telegram berhasil');
    return { ok: true };
  } catch (e) {
    console.error('[ipungg-store] backup Telegram gagal:', e.message);
    return { ok: false, error: e.message };
  } finally { backupBusy = false; }
}
function startTelegramBackup() {
  if (backupTimer) clearInterval(backupTimer);
  backupTimer = setInterval(() => { telegramBackup(false); }, 3600e3);
  backupTimer.unref?.();
}

async function sendChannel(channelId, text, imageUrl, channelLink = '') {
  const id = String(channelId || '').trim();
  const link = String(channelLink || '').trim();
  if (!id && !link) return false;
  if (S() || process.env.WEB_MODE === 'full') {
    const sock = S(); if (!localReady()) return false;
    try {
      let jid = id.includes('@') ? id : (/^\d{6,30}$/.test(id) ? `${id}@newsletter` : '');
      if (!jid && link) {
        const m = link.match(/whatsapp\.com\/channel\/([^/?#]+)/i);
        if (m && typeof sock.newsletterMetadata === 'function') {
          const meta = await sock.newsletterMetadata('invite', m[1]);
          if (meta && meta.id) jid = meta.id;
        }
      }
      if (!jid) throw new Error('ID/JID atau link saluran tidak valid');
      if (imageUrl) await sock.sendMessage(jid, { image: { url: imageUrl }, caption: text });
      else await sock.sendMessage(jid, { text });
      return true;
    } catch { return false; }
  }
  await enqueue('send-channel', { channelId: id, channelLink: link, text, imageUrl }, false); return true;
}

module.exports = { setSocket, ready, localReady, probe, takeJobs, finishJob, hasSocket: () => !!S(), addSewa, addSewaLocal, sendText, sendLocal, sendChannel, startPinger, telegramBackup, startTelegramBackup };

};

__defs['orders'] = function (module, exports, require) {
const db = require('./db');
const pay = require('./payment');
const bridge = require('./bridge');
const { newId, rupiah } = require('./util');

const fmt = (t) => new Date(t).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', dateStyle: 'medium', timeStyle: 'short' });
const locks = new Set();

async function create({ type, item, buyer, group, note }) {
  const d = db.get();
  const order = {
    id: 'IP' + Date.now().toString(36).toUpperCase() + newId(2).toUpperCase(),
    token: newId(12),
    type, // sewa | produk
    itemId: item.id, itemName: item.name,
    days: item.days || 0,
    amount: item.price,
    buyerName: buyer.name, buyerPhone: buyer.phone,
    groupLink: group || '', note: note || '',
    status: 'pending', // pending | paid | expired
    fulfil: 'waiting', // waiting | done | error
    result: null, error: '',
    createdAt: Date.now(), paidAt: null,
    expireAt: Date.now() + (d.settings.orderTtlMinutes || 15) * 60000,
  };
  const ch = await pay.createCharge(order);
  Object.assign(order, ch);
  // nominal yang HARUS dibayar (sudah termasuk kode unik) + masa berlaku QR dari gateway
  order.payAmount = Number(order.payAmount) > 0 ? Number(order.payAmount) : order.amount;
  const exp = Date.parse(order.expiredAt);
  if (Number.isFinite(exp) && exp > Date.now()) order.expireAt = exp;
  d.orders.unshift(order);
  db.save();
  return order;
}

async function fulfil(order) {
  if (order.fulfil === 'done' || locks.has(order.id)) return;
  locks.add(order.id);
  const d = db.get();
  const owner = String(process.env.OWNER_NUMBER || d.settings.ownerPhone || global.owner || '').replace(/\D/g, '');
  try {
    // Produk/source code dikirim lewat halaman web, bukan WhatsApp bot.
    // Cari produk sekali di awal supaya data foto/link juga bisa dipakai notifikasi Channel.
    const p = order.type === 'produk' ? d.products.find((x) => x.id === order.itemId) : null;
    if (order.type === 'sewa') {
      const r = await bridge.addSewa({ link: order.groupLink, days: order.days, key: order.id });
      order.result = { groupName: r.groupName, expired: r.expired, joinStatus: r.joinStatus };
      order.fulfil = 'done'; order.error = '';
      let t = `✅ *Sewa Bot Aktif*\n\nTerima kasih ${order.buyerName}!\n🏢 Grup: ${r.groupName}\n⏱️ Paket: ${order.itemName}\n📅 Berakhir: ${fmt(r.expired)}\n`;
      t += r.joinStatus === 'joined'
        ? 'Bot sudah masuk ke grup kamu.'
        : 'Bot belum masuk. Jika grup memakai persetujuan admin, mohon setujui permintaan bergabung dari bot.';
      t += `\n\nOrder: ${order.id}\n— ${d.settings.siteName}`;
      // Jangan kirim status/transaksi ke private chat pembeli.
      // Informasi transaksi sukses dikirim satu kali ke Saluran WhatsApp di bawah.
    } else {
      if (!p) throw new Error('Produk tidak ditemukan');
      // Delivery hanya di halaman order web. Jangan kirim link MediaFire/source ke WhatsApp.
      order.result = { url: p.url, note: p.note || '' };
      order.fulfil = 'done';
    }
    const channelId = String(d.settings.channelId || '').trim();
    const channelLink = String(d.settings.channelLink || '').trim();
    if ((channelId || channelLink) && !order.channelNotifiedAt) {
      // Channel: kirim foto produk yang dibeli, tanpa canvas dan tanpa link MediaFire.
      // Untuk sewa bot gunakan foto sewaImage bila tersedia.
      const imageUrl = order.type === 'produk' ? String((p && p.image) || '') : String(d.settings.sewaImage || '');
      const msg = `💰 *PEMBELIAN BERHASIL*\n\n📦 Produk: ${order.itemName}\n👤 Nama: ${order.buyerName}\n💵 Harga: ${rupiah(order.amount)}\n🧾 ID: ${order.id}\n🕒 Waktu: ${fmt(order.paidAt || Date.now())}\n\n— ${d.settings.siteName}`;
      try {
        const sent = await bridge.sendChannel(channelId, msg, imageUrl, channelLink);
        if (sent) order.channelNotifiedAt = Date.now();
        else console.error('[ipungg-store] notifikasi channel gagal dikirim');
      } catch (e) {
        console.error('[ipungg-store] notifikasi channel gagal:', e.message);
      }
    }
  } catch (e) {
    order.fulfil = 'error';
    order.error = e.message;
    console.error('[ipungg-store] fulfil gagal', order.id, e.message);
  } finally {
    locks.delete(order.id);
    db.save();
  }
}

async function markPaid(order) {
  if (order.status !== 'paid') { order.status = 'paid'; order.paidAt = Date.now(); delete order.qrImage; delete order.qrString; db.save(); }
  await fulfil(order);
}

async function refresh(order, { force = false } = {}) {
  if (order.status === 'cancelled') return order;
  if (order.status === 'paid') { if (order.fulfil !== 'done') await fulfil(order); return order; }
  if (order.status === 'expired') return order;
  if (Date.now() > order.expireAt + 60000) { order.status = 'expired'; delete order.qrImage; delete order.qrString; db.save(); return order; }
  // gateway meminta jeda minimal 5 detik antar cek status
  if (!force && Date.now() - (order.lastCheck || 0) < 6000) return order;
  order.lastCheck = Date.now();
  try {
    const st = await pay.checkStatus(order);
    if (st === 'paid') await markPaid(order);
    else if (st === 'expired') { order.status = 'expired'; delete order.qrImage; delete order.qrString; db.save(); }
  } catch (e) { /* gateway sementara error, coba lagi nanti */ }
  return order;
}

// Cek berkala: order pending + retry order yang sudah bayar tapi bot belum siap
function startWorker() {
  setInterval(async () => {
    for (const o of db.get().orders) {
      if (o.status === 'cancelled') continue;
      if (o.status === 'pending' && Date.now() < o.expireAt + 60000) await refresh(o);
      else if (o.status === 'paid' && o.fulfil !== 'done' && bridge.ready()) await fulfil(o);
      else if (o.status === 'pending') { o.status = 'expired'; db.save(); }
    }
  }, 10000).unref();
}

module.exports = { create, refresh, markPaid, fulfil, startWorker };

};

(function (require) {
const express = require('express');
const path = require('path');
const fs = require('fs');
const db = require('./lib/db');
const auth = require('./lib/auth');
const orders = require('./lib/orders');
const pay = require('./lib/payment');
const bridge = require('./lib/bridge');
const U = require('./lib/util');

const PUB = path.join(__dirname, 'public');
const UP = path.join(PUB, 'uploads');
const VERSION = 'web-2026.10.07-v11';

// Live visitor monitor (anonymous, in-memory). Used only for admin realtime counters.
const liveVisitors = new Map();
// Dibaca oleh bridge.telegramBackup() yang berada di module-scope terisolasi.
globalThis.__ipunggLiveVisitors = liveVisitors;
const visitorKey = (req) => String(req.headers['x-visitor-id'] || '').replace(/[^a-zA-Z0-9_-]/g,'').slice(0,64);
const touchVisitor = (req) => { const id=visitorKey(req); if(!id) return null; const now=Date.now(); liveVisitors.set(id,{last:now,path:String(req.headers['x-page']||'/').slice(0,120)}); return id; };
setInterval(()=>{ const cut=Date.now()-90000; for(const [id,v] of liveVisitors) if(v.last<cut) liveVisitors.delete(id); },30000).unref();
let started = false;
const isLocal = (u) => /^\/uploads\/[A-Za-z0-9._-]+$/.test(String(u || ''));
// hanya hapus file hasil unggahan; link luar (https://...) tidak pernah menyentuh disk
const rmUpload = (u) => { if (!isLocal(u)) return; try { fs.unlinkSync(path.join(UP, path.basename(String(u)))); } catch {} };
const okImage = (u) => {
  u = String(u || '').trim();
  if (isLocal(u)) return u;
  if (u.length <= 500 && /^https:\/\/[^\s"'<>\\]+$/i.test(u)) { try { new URL(u); return u; } catch {} }
  return '';
};
const audioExt = (b) => {
  if (!Buffer.isBuffer(b) || b.length < 12) return '';
  const t = (a, z) => b.slice(a, z).toString('latin1');
  if (t(0, 3) === 'ID3' || (b[0] === 0xff && (b[1] & 0xe0) === 0xe0)) return 'mp3';
  if (t(0, 4) === 'OggS') return 'ogg';
  if (t(0, 4) === 'RIFF' && t(8, 12) === 'WAVE') return 'wav';
  if (t(4, 8) === 'ftyp') return 'm4a';
  return '';
};
// hapus file upload yatim (tidak dipakai & lebih dari 1 jam)
function gcUploads() {
  try {
    const d = db.get(); const used = new Set();
    [d.settings.logo, d.settings.thumbnail, d.settings.sewaImage, d.settings.audio, ...d.products.map((p) => p.image)].filter(isLocal).forEach((u) => used.add(path.basename(u)));
    for (const f of fs.readdirSync(UP)) {
      if (f.startsWith('.') || used.has(f)) continue;
      if (Date.now() - fs.statSync(path.join(UP, f)).mtimeMs > 3600e3) fs.unlinkSync(path.join(UP, f));
    }
  } catch {}
}

const publicOrder = (o) => ({
  id: o.id, type: o.type, itemName: o.itemName, amount: o.amount, payAmount: o.payAmount || o.amount, status: o.status, fulfil: o.fulfil,
  qrImage: o.qrImage || '', qrString: o.qrString || '', payUrl: o.payUrl || '',
  expireAt: o.expireAt, createdAt: o.createdAt, result: o.status === 'paid' ? o.result : null,
});

function createApp({ botOnly = false } = {}) {
  const app = express();
  app.set('trust proxy', 1);
  app.disable('x-powered-by');
  app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Referrer-Policy', 'same-origin');
    next();
  });
  app.use(express.json({ limit: '4mb' }));

  // Mode maintenance: toko publik ditutup, tetapi dashboard admin, bot bridge,
  // webhook pembayaran, dan aset admin tetap bisa diakses.
  app.use((req, res, next) => {
    try {
      if (botOnly || !db.get().settings.maintenance) return next();
      const p = req.path || '';
      const allowed = p === '/admin' || p === '/admin.html' || p.startsWith('/api/admin') ||
        p.startsWith('/api/bot') || p.startsWith('/api/webhook/payment') || p.startsWith('/api/channel-card/') ||
        p.startsWith('/js/admin') || p.startsWith('/css/') || p === '/favicon.ico';
      if (allowed) return next();
      if (p.startsWith('/api/')) return res.status(503).json({ ok: false, error: 'Website sedang maintenance', maintenance: true });
      res.status(503).type('html').send(`<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Maintenance</title><style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#080808;color:#fff;font-family:Arial,sans-serif;text-align:center}main{max-width:520px;padding:32px}h1{color:#ff2638;font-size:42px;margin:0 0 12px}p{color:#aaa;line-height:1.6}.dot{display:inline-block;width:10px;height:10px;background:#ff2638;border-radius:50%;box-shadow:0 0 18px #ff2638;margin:0 4px}</style></head><body><main><div class="dot"></div><div class="dot"></div><div class="dot"></div><h1>Website Maintenance</h1><p>Website sedang dalam perbaikan atau pembaruan.<br>Silakan kembali beberapa saat lagi.</p></main></body></html>`);
    } catch { next(); }
  });

  const ok = (res, extra = {}) => res.json({ ok: true, ...extra });
  const fail = (res, msg, code = 400) => res.status(code).json({ ok: false, error: msg });
  const wrap = (fn) => (req, res) => Promise.resolve(fn(req, res)).catch((e) => { console.error('[web]', e.message); fail(res, e.public || e.message || 'Terjadi kesalahan', 500); });

  // ---------- API UNTUK WEB DI SERVER LAIN (pakai x-api-key) ----------
  const B = express.Router();
  B.use(auth.requireBot);
  B.post('/visitor/ping', (req,res)=>{ touchVisitor(req); ok(res,{online:true}); });
  B.get('/ping', (req, res) => ok(res, { online: bridge.localReady(), hasSocket: bridge.hasSocket(), version: VERSION }));
  B.post('/addsewa', wrap(async (req, res) => {
    const link = U.clean((req.body || {}).link, 120), days = parseInt((req.body || {}).days, 10);
    if (!U.validGroupLink(link) || !(days >= 1 && days <= 1000)) return fail(res, 'Data sewa tidak valid');
    ok(res, { result: await bridge.addSewaLocal({ link, days }) });
  }));
  B.post('/send', wrap(async (req, res) => {
    const phone = U.normPhone((req.body || {}).phone), text = U.cleanMultiline((req.body || {}).text, 2000);
    if (!U.validPhone(phone) || !text) return fail(res, 'Data pesan tidak valid');
    ok(res, { sent: await bridge.sendLocal(phone, text) });
  }));
  // jalur "bot menjemput pekerjaan" (plugin ipungg-link di server bot memanggil ini)
  B.post('/link/poll', (req, res) => ok(res, { jobs: bridge.takeJobs(req.body) }));
  B.post('/link/result', (req, res) => {
    const b = req.body || {};
    bridge.finishJob(String(b.id || ''), !!b.ok, b.ok ? b.result : b.error);
    ok(res);
  });
  app.use('/api/bot', B);
  if (botOnly) { app.use((req, res) => fail(res, 'Tidak ada', 404)); return app; }
  app.use(express.static(PUB, { extensions: ['html'], maxAge: '1h', setHeaders: (res, f) => { if (/\.html$/i.test(f)) res.setHeader('Cache-Control', 'no-cache'); } }));

  // ---------- PUBLIC ----------
  app.get('/api/channel-card/:id.svg', (req, res) => {
    const d = db.get(); const o = d.orders.find(x => x.id === String(req.params.id)); const site = d.settings;
    if (!o) return res.status(404).type('text/plain').send('Not found');
    const escSvg = (v) => U.esc(String(v ?? ''));
    const title = escSvg(site.siteName || 'Store');
    const item = escSvg(o.itemName || '-');
    const buyer = escSvg(o.buyerName || '-');
    const amount = escSvg(U.rupiah(o.amount));
    const id = escSvg(o.id);
    const time = escSvg(new Date(o.paidAt || Date.now()).toLocaleString('id-ID', { dateStyle: 'medium', timeStyle: 'short' }));
    const logo = site.logo ? `<image href="${escSvg(site.logo)}" x="44" y="42" width="76" height="76" preserveAspectRatio="xMidYMid slice"/>` : '';
    const svg = `<?xml version="1.0" encoding="UTF-8"?><svg xmlns="http://www.w3.org/2000/svg" width="900" height="620" viewBox="0 0 900 620"><rect width="900" height="620" rx="28" fill="#0b1220"/><rect x="1" y="1" width="898" height="618" rx="27" fill="none" stroke="#1e3355" stroke-width="2"/>${logo}<text x="145" y="78" fill="#f5f7fb" font-family="Arial,sans-serif" font-size="32" font-weight="700">${title}</text><text x="145" y="108" fill="#6f86a8" font-family="Arial,sans-serif" font-size="18">STRUK TRANSAKSI</text><line x1="44" y1="145" x2="856" y2="145" stroke="#203451"/><text x="44" y="192" fill="#6f86a8" font-family="Arial,sans-serif" font-size="18">Produk</text><text x="856" y="192" text-anchor="end" fill="#f5f7fb" font-family="Arial,sans-serif" font-size="24" font-weight="700">${item}</text><text x="44" y="245" fill="#6f86a8" font-family="Arial,sans-serif" font-size="18">Pembeli</text><text x="856" y="245" text-anchor="end" fill="#f5f7fb" font-family="Arial,sans-serif" font-size="22">${buyer}</text><text x="44" y="298" fill="#6f86a8" font-family="Arial,sans-serif" font-size="18">No. Transaksi</text><text x="856" y="298" text-anchor="end" fill="#f5f7fb" font-family="Arial,sans-serif" font-size="22">${id}</text><text x="44" y="351" fill="#6f86a8" font-family="Arial,sans-serif" font-size="18">Tanggal</text><text x="856" y="351" text-anchor="end" fill="#f5f7fb" font-family="Arial,sans-serif" font-size="20">${time}</text><line x1="44" y1="390" x2="856" y2="390" stroke="#203451"/><text x="44" y="438" fill="#6f86a8" font-family="Arial,sans-serif" font-size="18">TOTAL BAYAR</text><text x="44" y="490" fill="#36e0a0" font-family="Arial,sans-serif" font-size="42" font-weight="700">${amount}</text><text x="44" y="552" fill="#526b8e" font-family="Arial,sans-serif" font-size="16">Pembelian berhasil • ${title}</text></svg>`;
    res.setHeader('Cache-Control', 'no-store'); res.type('image/svg+xml').send(svg);
  });
  app.get('/api/public', (req, res) => {
    const d = db.get();
    const s = d.settings;
    ok(res, {
      site: { name: s.siteName, logo: s.logo, thumbnail: s.thumbnail, sewaImage: s.sewaImage || '', whatsapp: s.whatsapp, telegram: s.telegram, contactNote: s.contactNote || '',
        audio: s.audioOn !== false && s.audio ? s.audio : '', audioVolume: Number.isFinite(s.audioVolume) ? s.audioVolume : 40 },
      plans: d.plans.map(({ id, name, days, price }) => ({ id, name, days, price })),
      products: d.products.filter((p) => p.active !== false).map(({ id, name, price, image, categoryId }) => ({ id, name, price, image: image || '', categoryId: categoryId || '' })),
      categories: (d.categories || []).filter((c) => d.products.some((p) => p.active !== false && p.categoryId === c.id)).map(({ id, name }) => ({ id, name })),
      botOnline: bridge.ready(),
    });
  });

  app.post('/api/order/sewa', auth.limit('order', 8, 10 * 60e3), wrap(async (req, res) => {
    const d = db.get();
    const b = req.body || {};
    const plan = d.plans.find((p) => p.id === b.planId);
    if (!plan) return fail(res, 'Paket tidak ditemukan');
    const name = U.clean(b.name, 60), phone = U.normPhone(b.phone), link = U.clean(b.link, 120), note = U.cleanMultiline(b.note, 300);
    if (name.length < 2) return fail(res, 'Nama minimal 2 huruf');
    if (!U.validPhone(phone)) return fail(res, 'Nomor WhatsApp tidak valid (contoh 08123456789)');
    if (!U.validGroupLink(link)) return fail(res, 'Link grup harus berbentuk https://chat.whatsapp.com/xxxx');
    const dup = d.orders.find((o) => o.type === 'sewa' && o.status === 'pending' && o.groupLink === link && Date.now() < o.expireAt);
    if (dup) return ok(res, { id: dup.id, token: dup.token, reused: true });
    const o = await orders.create({ type: 'sewa', item: plan, buyer: { name, phone }, group: link, note });
    ok(res, { id: o.id, token: o.token });
  }));

  app.post('/api/order/produk', auth.limit('order', 8, 10 * 60e3), wrap(async (req, res) => {
    const d = db.get();
    const b = req.body || {};
    const p = d.products.find((x) => x.id === b.productId && x.active !== false);
    if (!p) return fail(res, 'Produk tidak ditemukan');
    const name = U.clean(b.name, 60), phone = U.normPhone(b.phone);
    if (name.length < 2) return fail(res, 'Nama minimal 2 huruf');
    if (!U.validPhone(phone)) return fail(res, 'Nomor WhatsApp tidak valid (contoh 08123456789)');
    const o = await orders.create({ type: 'produk', item: p, buyer: { name, phone } });
    ok(res, { id: o.id, token: o.token });
  }));

  app.post('/api/order/:id/cancel', wrap(async (req, res) => {
    const d = db.get();
    const o = d.orders.find((x) => x.id === req.params.id);
    if (!o || o.token !== String(req.query.t || '')) return fail(res, 'Pesanan tidak ditemukan', 404);
    if (o.status === 'paid') return fail(res, 'Pesanan sudah dibayar dan tidak bisa dibatalkan', 409);
    if (o.status === 'cancelled') return ok(res);
    if (o.status === 'expired') return fail(res, 'Pesanan sudah kedaluwarsa', 409);
    o.status = 'cancelled';
    o.cancelledAt = Date.now();
    delete o.qrImage; delete o.qrString;
    db.save();
    ok(res);
  }));

  app.get('/api/order/:id', wrap(async (req, res) => {
    const o = db.get().orders.find((x) => x.id === req.params.id);
    if (!o || o.token !== String(req.query.t || '')) return fail(res, 'Pesanan tidak ditemukan', 404);
    await orders.refresh(o, { force: String(req.query.force || '') === '1' });
    const out = publicOrder(o);
    if (!out.qrImage && out.qrString && o.status === 'pending') {
      try { out.qrImage = await require('qrcode').toDataURL(out.qrString, { margin: 1, width: 360 }); } catch {}
    }
    ok(res, { order: out });
  }));

  // webhook gateway: tidak dipercaya mentah, status selalu diverifikasi ulang ke gateway
  app.all('/api/webhook/payment', wrap(async (req, res) => {
    const src = { ...(req.query || {}), ...(req.body || {}) };
    const dd = src.data && typeof src.data === 'object' ? src.data : {};
    const ref = U.clean(dd.transactionId || dd.transaction_id || src.transactionId || src.order_id || src.reference || src.ref || src.id || src.trx_id, 80);
    ok(res); // AustinPay menunggu balasan 2xx maksimal 10 detik
    const o = db.get().orders.find((x) => x.id === ref || x.trxId === ref);
    if (o) orders.refresh(o, { force: true }).catch(() => {}); // status selalu diverifikasi ulang ke gateway
  }));

  // ---------- ADMIN ----------
  app.post('/api/admin/login', auth.limit('login', 6, 15 * 60e3), (req, res) => {
    const { username, password } = req.body || {};
    const a = db.get().admin;
    if (String(username) !== a.user || !db.verifyPassword(password, a.hash)) return fail(res, 'Username atau password salah', 401);
    auth.setCookie(res, auth.issue(a.user), req);
    ok(res);
  });
  app.post('/api/admin/logout', (req, res) => { auth.clearCookie(res); ok(res); });

  const A = express.Router();
  A.use(auth.requireAdmin);

  A.get('/me', (req, res) => ok(res, { user: db.get().admin.user }));
  // laporan satu halaman: bot + pembayaran (tanpa membocorkan API key)
  A.get('/diagnosa', wrap(async (req, res) => {
    const s = db.get().settings, p = s.payment;
    const rawUrl = process.env.BOT_URL || s.botUrl || '';
    let shown = rawUrl; try { const u = new URL(rawUrl); u.username = ''; u.password = ''; shown = u.origin; } catch { shown = rawUrl.slice(0, 80); }
    const bot = await bridge.probe();
    const out = {
      version: VERSION, node: process.version, time: Date.now(), egressIp: await pay.egressIp(),
      bot: { mode: (typeof lastPoll === 'number' && lastPoll > 0 && Date.now() - lastPoll < 20000) ? 'sambung otomatis (plugin)' : rawUrl ? 'remote (API)' : process.env.WEB_MODE === 'full' ? 'satu server' : 'sambung otomatis (plugin)', url: shown, keyFilled: !!(process.env.BOT_API_KEY || s.botApiKey), ...bot },
      payment: { baseUrl: p.baseUrl, createPath: p.createPath, statusPath: p.statusPath, method: p.method, keyFilled: !!p.apikey, lastError: pay.getLastError() },
    };
    if (req.query.pay === '1') out.payment.test = await pay.testCreate();
    ok(res, out);
  }));
  // perintah sambung untuk dikirim ke bot lewat WhatsApp (berisi alamat toko + kunci, tidak perlu diketik manual)
  A.post('/pair-code', (req, res) => {
    const origin = String((req.body || {}).origin || '').trim().replace(/\/+$/, '');
    if (!U.validUrl(origin)) return fail(res, 'Alamat toko tidak valid (contoh http://panel1.warhead1.shop:3155)');
    const key = process.env.BOT_API_KEY || db.get().settings.botApiKey;
    const code = Buffer.from(JSON.stringify({ u: origin, k: key })).toString('base64url');
    ok(res, { command: '.sambungweb ' + code });
  });
  A.post('/payment-preset', (req, res) => { db.applyAustin(db.get().settings.payment); db.save(); ok(res); });
  A.get('/egress-ip', wrap(async (req, res) => ok(res, { ip: await pay.egressIp() })));
  A.post('/payment-test', wrap(async (req, res) => ok(res, await pay.testCreate())));
  A.get('/bot-status', wrap(async (req, res) => ok(res, await bridge.probe())));

  A.get('/overview', (req, res) => {
    const d = db.get(); const paid = d.orders.filter((o) => o.status === 'paid');
    const today = new Date().toDateString(); const active=[...liveVisitors.values()].filter(v=>Date.now()-v.last<90000);
    ok(res, {
      totalOrders: paid.length, revenue: paid.reduce((a,o)=>a+Number(o.amount||0),0),
      todayRevenue: paid.filter(o=>new Date(o.paidAt||0).toDateString()===today).reduce((a,o)=>a+Number(o.amount||0),0),
      todayOrders: d.orders.filter(o=>new Date(o.createdAt||0).toDateString()===today).length,
      pending: d.orders.filter(o=>o.status==='pending').length,
      needAttention: d.orders.filter(o=>o.status==='paid' && o.fulfil!=='done').length,
      botOnline: bridge.ready(), maintenance: !!d.settings.maintenance,
      visitorsOnline: active.length, visitorsTotal: liveVisitors.size,
      recentVisitors: active.slice(-20).map(v=>({last:v.last,path:v.path}))
    });
  });

  A.get('/orders', (req, res) => {
    const list = db.get().orders.slice(0, 500).map((o) => ({
      id: o.id, type: o.type, itemName: o.itemName, amount: o.amount, buyerName: o.buyerName, buyerPhone: o.buyerPhone,
      groupLink: o.groupLink, note: o.note, status: o.status, fulfil: o.fulfil, error: o.error, createdAt: o.createdAt, paidAt: o.paidAt, result: o.result,
    }));
    ok(res, { orders: list });
  });
  A.post('/orders/:id/retry', wrap(async (req, res) => {
    const o = db.get().orders.find((x) => x.id === req.params.id);
    if (!o || o.status !== 'paid') return fail(res, 'Hanya pesanan yang sudah dibayar yang bisa diproses ulang');
    o.fulfil = 'waiting'; await orders.fulfil(o);
    ok(res, { fulfil: o.fulfil, error: o.error });
  }));

  A.get('/plans', (req, res) => ok(res, { plans: db.get().plans }));
  A.put('/plans/:id', (req, res) => {
    const p = db.get().plans.find((x) => x.id === req.params.id);
    if (!p) return fail(res, 'Paket tidak ditemukan', 404);
    const price = parseInt(req.body.price, 10), days = parseInt(req.body.days, 10);
    if (!(price >= 1)) return fail(res, 'Harga minimal Rp1');
    if (!(days >= 1 && days <= 1000)) return fail(res, 'Durasi 1–1000 hari');
    p.price = price; p.days = days;
    if (req.body.name) p.name = U.clean(req.body.name, 30);
    db.save(); ok(res);
  });

  const productFields = (b) => {
    const name = U.clean(b.name, 80), price = parseInt(b.price, 10), url = U.clean(b.url, 400);
    if (name.length < 2) throw new Error('Nama produk wajib diisi');
    if (!(price >= 1)) throw new Error('Harga minimal Rp1');
    if (!U.validUrl(url)) throw new Error('Link MediaFire tidak valid');
    if (b.image && !okImage(b.image)) throw new Error('Link foto harus diawali https:// (atau unggah file)');
    return { name, price, url, note: U.cleanMultiline(b.note, 400), desc: U.clean(b.desc, 160), image: okImage(b.image),
      categoryId: (db.get().categories || []).some((c) => c.id === b.categoryId) ? b.categoryId : '', active: b.active !== false };
  };
  A.get('/products', (req, res) => ok(res, { products: db.get().products }));
  A.post('/products', (req, res) => {
    try { const p = { id: 'p_' + U.newId(4), ...productFields(req.body || {}) }; db.get().products.push(p); db.save(); ok(res, { product: p }); }
    catch (e) { fail(res, e.message); }
  });
  A.put('/products/:id', (req, res) => {
    const d = db.get(); const i = d.products.findIndex((x) => x.id === req.params.id);
    if (i < 0) return fail(res, 'Produk tidak ditemukan', 404);
    try {
      const old = d.products[i];
      const next = { id: old.id, ...productFields(req.body || {}) };
      if (old.image && old.image !== next.image) rmUpload(old.image);
      d.products[i] = next; db.save(); ok(res);
    } catch (e) { fail(res, e.message); }
  });
  A.delete('/products/:id', (req, res) => {
    const d = db.get(); const old = d.products.find((x) => x.id === req.params.id);
    if (old) rmUpload(old.image);
    d.products = d.products.filter((x) => x.id !== req.params.id); db.save(); ok(res);
  });

  const catName = (b) => {
    const n = U.clean((b || {}).name, 30);
    if (n.length < 2) throw new Error('Nama kategori minimal 2 huruf');
    return n;
  };
  A.get('/categories', (req, res) => {
    const d = db.get();
    ok(res, { categories: (d.categories || []).map((c) => ({ ...c, count: d.products.filter((p) => p.categoryId === c.id).length })) });
  });
  A.post('/categories', (req, res) => {
    try {
      const d = db.get(); const name = catName(req.body);
      d.categories = d.categories || [];
      if (d.categories.some((c) => c.name.toLowerCase() === name.toLowerCase())) return fail(res, 'Kategori sudah ada');
      d.categories.push({ id: 'c_' + U.newId(3), name }); db.save(); ok(res);
    } catch (e) { fail(res, e.message); }
  });
  A.put('/categories/:id', (req, res) => {
    try {
      const d = db.get(); const c = (d.categories || []).find((x) => x.id === req.params.id);
      if (!c) return fail(res, 'Kategori tidak ditemukan', 404);
      const name = catName(req.body);
      if (d.categories.some((x) => x.id !== c.id && x.name.toLowerCase() === name.toLowerCase())) return fail(res, 'Nama kategori sudah dipakai');
      c.name = name; db.save(); ok(res);
    } catch (e) { fail(res, e.message); }
  });
  A.delete('/categories/:id', (req, res) => {
    const d = db.get();
    d.categories = (d.categories || []).filter((x) => x.id !== req.params.id);
    d.products.forEach((p) => { if (p.categoryId === req.params.id) p.categoryId = ''; });
    db.save(); ok(res);
  });

  const mask = (k) => (k ? '••••' + String(k).slice(-4) : '');
  A.get('/settings', (req, res) => {
    const s = db.get().settings; const p = s.payment;
    ok(res, {
      siteName: s.siteName, logo: s.logo, thumbnail: s.thumbnail, sewaImage: s.sewaImage || '', whatsapp: s.whatsapp, telegram: s.telegram, telegramBackupTokenMasked: mask(s.telegramBackupToken), telegramBackupChatId: s.telegramBackupChatId || '', channelId: s.channelId || '', channelLink: s.channelLink || '', publicUrl: s.publicUrl || '', maintenance: !!s.maintenance,
      orderTtlMinutes: s.orderTtlMinutes,
      contactNote: s.contactNote || '', lastPaymentError: pay.getLastError(),
      audio: s.audio || '', audioOn: s.audioOn !== false, audioVolume: Number.isFinite(s.audioVolume) ? s.audioVolume : 40,
      botApiKeyMasked: mask(process.env.BOT_API_KEY || s.botApiKey),
      botUrl: s.botUrl || '', ownerPhone: s.ownerPhone || '',
      botMode: (process.env.BOT_URL || s.botUrl) ? 'remote (API)' : process.env.WEB_MODE === 'full' ? 'satu server' : 'sambung otomatis (plugin)',
      payment: { ...p, apikey: '', apikeyMasked: mask(p.apikey), apiSecret: '', apiSecretMasked: mask(p.apiSecret) },
      botOnline: bridge.ready(),
      github: { owner: s.github?.owner || '', repo: s.github?.repo || '', branch: s.github?.branch || 'main', path: s.github?.path || 'data/db.json' },
      webhookPath: '/api/webhook/payment',
    });
  });
  A.post('/telegram-backup/test', wrap(async (req, res) => ok(res, await bridge.telegramBackup(true))));
  A.post('/github-test', wrap(async (req, res) => {
    const b = req.body || {};
    const token = String(b.token || '').trim();
    const owner = String(b.owner || '').trim();
    const repo = String(b.repo || '').trim();
    const branch = String(b.branch || 'main').trim();
    const filePath = String(b.path || 'data/db.json').trim().replace(/^\/+/, '');
    if (!token || !owner || !repo || !branch || !filePath) return fail(res, 'Token, owner, repository, branch, dan path wajib diisi');
    if (!/^[A-Za-z0-9_.-]{1,100}$/.test(owner) || !/^[A-Za-z0-9_.-]{1,100}$/.test(repo)) return fail(res, 'Owner atau nama repository tidak valid');
    const headers = { Authorization: `Bearer ${token}`, Accept: 'application/vnd.github+json', 'X-GitHub-Api-Version': '2022-11-28', 'User-Agent': 'IPUNGG-STORE' };
    try {
      const r = await axios.get(`https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}`, { headers, timeout: 12000 });
      if (r.data?.private !== true) return fail(res, 'Repository harus Private. Token tidak disimpan.');
      const content = await axios.get(`https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/contents/${filePath.split('/').map(encodeURIComponent).join('/')}`, { headers, params: { ref: branch }, timeout: 12000 });
      if (content.data?.type !== 'file') return fail(res, 'Path tidak mengarah ke file. Token tidak disimpan.');
      ok(res, { message: `Berhasil terhubung ke repository Private ${owner}/${repo}; file ${filePath} ditemukan pada branch ${branch}. Token tidak disimpan.` });
    } catch (e) {
      const status = e.response?.status;
      const message = status === 401 ? 'Token tidak valid atau sudah kedaluwarsa.' : status === 403 ? 'Akses ditolak. Periksa izin Contents dan akses repository pada token.' : status === 404 ? 'Repository atau file tidak ditemukan. Periksa owner, nama repo, branch, dan path.' : `Tes koneksi gagal${status ? ` (HTTP ${status})` : ''}.`;
      fail(res, message, status === 401 ? 401 : 400);
    }
  }));
  A.put('/settings', (req, res) => {
    const s = db.get().settings; const b = req.body || {};
    if (b.siteName !== undefined) { const n = U.clean(b.siteName, 40); if (n.length < 2) return fail(res, 'Nama web minimal 2 huruf'); s.siteName = n; }
    if (b.whatsapp !== undefined) s.whatsapp = U.clean(b.whatsapp, 200);
    if (b.telegram !== undefined) s.telegram = U.clean(b.telegram, 200);
    if (b.telegramBackupToken !== undefined && b.telegramBackupToken !== '') s.telegramBackupToken = U.clean(b.telegramBackupToken, 300);
    if (b.telegramBackupChatId !== undefined) s.telegramBackupChatId = U.clean(b.telegramBackupChatId, 100);
    if (b.channelId !== undefined) s.channelId = U.clean(b.channelId, 120);
    if (b.maintenance !== undefined) s.maintenance = !!b.maintenance;
    if (b.publicUrl !== undefined) { const v = U.clean(b.publicUrl, 300); if (v && !U.validUrl(v)) return fail(res, 'Alamat toko harus URL http/https'); s.publicUrl = v; }
    if (b.channelLink !== undefined) { const v = U.clean(b.channelLink, 300); if (v && !/^https?:\/\/wa\.me\/channel\//i.test(v) && !/^https?:\/\/whatsapp\.com\/channel\//i.test(v)) return fail(res, 'Link saluran WhatsApp tidak valid'); s.channelLink = v; }
    if (b.contactNote !== undefined) s.contactNote = U.cleanMultiline(b.contactNote, 200);
    for (const k of ['logo', 'thumbnail', 'sewaImage']) {
      if (b[k] === undefined) continue;
      const v = String(b[k] || '').trim();
      if (v && !okImage(v)) return fail(res, 'Link gambar harus diawali https:// (atau unggah file)');
      if (s[k] !== v) rmUpload(s[k]);
      s[k] = v;
    }
    if (b.audioOn !== undefined) s.audioOn = !!b.audioOn;
    if (b.audioVolume !== undefined) s.audioVolume = Math.min(100, Math.max(0, parseInt(b.audioVolume, 10) || 0));
    if (b.audioUrl !== undefined) {
      const v = String(b.audioUrl || '').trim();
      if (v && !U.validUrl(v)) return fail(res, 'URL audio harus diawali https://');
      if (v) rmUpload(s.audio);
      s.audio = v;
    }
    if (b.orderTtlMinutes !== undefined) s.orderTtlMinutes = Math.min(120, Math.max(5, parseInt(b.orderTtlMinutes, 10) || 15));
    if (b.botApiKey) s.botApiKey = U.clean(b.botApiKey, 120);
    if (b.botUrl !== undefined) {
      const u = U.clean(b.botUrl, 200).replace(/\/+$/, '');
      if (u && !U.validUrl(u)) return fail(res, 'URL server bot tidak valid (contoh http://1.2.3.4:25570)');
      s.botUrl = u;
    }
    if (b.ownerPhone !== undefined) s.ownerPhone = U.normPhone(b.ownerPhone);
    if (b.github && typeof b.github === 'object') {
      const g = b.github;
      const owner = U.clean(g.owner, 100), repo = U.clean(g.repo, 100), branch = U.clean(g.branch || 'main', 100), filePath = U.clean(g.path || 'data/db.json', 200).replace(/^\/+/, '');
      if (owner && !/^[A-Za-z0-9_.-]+$/.test(owner)) return fail(res, 'Owner GitHub tidak valid');
      if (repo && !/^[A-Za-z0-9_.-]+$/.test(repo)) return fail(res, 'Nama repository GitHub tidak valid');
      if (filePath.split('/').some((x) => !x || x === '.' || x === '..')) return fail(res, 'Path file database tidak valid');
      s.github = { owner, repo, branch: branch || 'main', path: filePath || 'data/db.json' };
    }
    if (b.payment) {
      const p = s.payment, n = b.payment;
      if (n.apikey) p.apikey = U.clean(n.apikey, 200);
      if (n.apiSecret) p.apiSecret = U.clean(n.apiSecret, 200);
      if (n.clearSecret) p.apiSecret = '';
      for (const k of ['baseUrl', 'createPath', 'statusPath', 'keyField', 'amountField', 'refField', 'paidValues', 'expiredValues'])
        if (n[k] !== undefined) p[k] = U.clean(n[k], 200);
      if (n.baseUrl !== undefined && !U.validUrl(p.baseUrl)) return fail(res, 'Base URL payment tidak valid');
      if (['GET', 'POST'].includes(n.method)) p.method = n.method;
      if (['GET', 'POST'].includes(n.statusMethod)) p.statusMethod = n.statusMethod;
      if (['query', 'body', 'header', 'bearer'].includes(n.authMode)) p.authMode = n.authMode;
      if (['json', 'form'].includes(n.bodyFormat)) p.bodyFormat = n.bodyFormat;
      if (n.map) for (const k of Object.keys(p.map)) if (n.map[k] !== undefined) p.map[k] = U.clean(n.map[k], 80);
    }
    db.save(); ok(res);
  });

  A.post('/upload/:kind', (req, res) => {
    const kind = req.params.kind;
    const KEYS = { logo: 'logo', thumbnail: 'thumbnail', sewa: 'sewaImage', produk: null };
    if (!(kind in KEYS)) return fail(res, 'Jenis tidak dikenal');
    const m = /^data:(image\/(png|jpeg|webp));base64,([A-Za-z0-9+/=]+)$/.exec(String((req.body || {}).data || ''));
    if (!m) return fail(res, 'Format harus PNG, JPG, atau WebP');
    const buf = Buffer.from(m[3], 'base64');
    if (buf.length > 2 * 1024 * 1024) return fail(res, 'Ukuran maksimal 2 MB');
    const ext = m[2] === 'jpeg' ? 'jpg' : m[2];
    fs.mkdirSync(UP, { recursive: true });
    const name = `${kind}-${U.newId(4)}.${ext}`;
    fs.writeFileSync(path.join(UP, name), buf);
    const url = '/uploads/' + name;
    const key = KEYS[kind];
    if (key) { const s = db.get().settings; rmUpload(s[key]); s[key] = url; db.save(); }
    ok(res, { url });
  });

  A.post('/audio', express.raw({ type: (r) => /^audio\//i.test(r.headers['content-type'] || ''), limit: '10mb' }), (req, res) => {
    const buf = req.body;
    if (!Buffer.isBuffer(buf) || !buf.length) return fail(res, 'File audio tidak terbaca');
    const ext = audioExt(buf);
    if (!ext) return fail(res, 'Format harus MP3, M4A, OGG, atau WAV');
    fs.mkdirSync(UP, { recursive: true });
    const name = `audio-${U.newId(4)}.${ext}`;
    fs.writeFileSync(path.join(UP, name), buf);
    const s = db.get().settings;
    rmUpload(s.audio); s.audio = '/uploads/' + name;
    if (s.audioOn === undefined) s.audioOn = true;
    db.save(); ok(res, { url: s.audio });
  });
  A.delete('/audio', (req, res) => { const s = db.get().settings; rmUpload(s.audio); s.audio = ''; db.save(); ok(res); });

  A.post('/account', (req, res) => {
    const d = db.get(); const { current, username, password } = req.body || {};
    if (!db.verifyPassword(current, d.admin.hash)) return fail(res, 'Password saat ini salah', 403);
    if (String(password || '').length < 8) return fail(res, 'Password baru minimal 8 karakter');
    d.admin.hash = db.hashPassword(password);
    if (username) d.admin.user = U.clean(username, 30);
    db.save(); auth.clearCookie(res); ok(res);
  });

  app.use('/api/admin', A);
  app.use('/api', (req, res) => fail(res, 'Endpoint tidak ada', 404));
  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    const big = err && (err.type === 'entity.too.large' || err.status === 413);
    res.status((err && err.status) || 500).json({ ok: false, error: big ? 'File terlalu besar' : 'Permintaan tidak valid' });
  });
  return app;
}

// Dipanggil dari dalam proses bot supaya web bisa memakai socket WhatsApp yang sama.
function start(sock, opts = {}) {
  if (sock) bridge.setSocket(sock);
  if (started) return;
  started = true;
  db.load();
  gcUploads(); setInterval(gcUploads, 6 * 3600e3).unref();
  const botOnly = process.env.WEB_MODE === 'bot';
  if (botOnly && (!process.env.BOT_API_KEY || process.env.BOT_API_KEY === 'GANTI_DENGAN_KUNCI_RAHASIA'))
    console.error('[ipungg-store] PERINGATAN: BOT_API_KEY belum diisi. Isi di Startup (Environment Variables) atau di handler.js, samakan dengan server web.');
  const port = opts.port || process.env.SERVER_PORT || process.env.PORT || 3000;
  createApp({ botOnly }).listen(port, () => console.log(`[ipungg-store] ${botOnly ? 'API bot' : 'web'} aktif di port ${port}`));
  if (botOnly) return;
  bridge.startPinger();
  orders.startWorker();
  bridge.startTelegramBackup();
}

module.exports = { start, createApp };

// jalan mandiri untuk tes: node web/server.js
if (__realRequire.main === module) { start(null); }

})(__req);
