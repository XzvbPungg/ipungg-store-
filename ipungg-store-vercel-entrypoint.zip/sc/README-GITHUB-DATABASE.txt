IPUNGG STORE — Dashboard Database GitHub

Perubahan dalam paket ini:
- Menu Database ditambahkan ke dashboard admin.
- Bisa mengisi owner/repository/branch/path dan mengetes akses token GitHub ke repo Private.
- Token yang dimasukkan untuk tes tidak disimpan ke db.json.
- Login default diset menjadi admin / admin2010.
- Token/API secret yang sebelumnya ada di salinan database dikosongkan untuk keamanan; masukkan ulang di dashboard setelah deploy.

PENTING:
Menu ini baru menyimpan metadata repository dan mengetes koneksi. Ini BELUM mengalihkan seluruh operasi database aplikasi ke GitHub API. Jangan mengandalkan GitHub sebagai database aktif sebelum adapter penyimpanan dan penanganan konflik transaksi benar-benar diimplementasikan dan diuji.

Untuk tes koneksi:
- Gunakan repository Private.
- Buat fine-grained token yang dibatasi hanya ke repository tujuan, izin Contents: Read and write.
- Token hanya dipakai saat tombol Tes koneksi dan tidak disimpan di aplikasi.
- Untuk backend memakai token secara permanen, simpan GH_TOKEN sebagai Environment Variable di Vercel; jangan masukkan token ke source code atau file JSON.
