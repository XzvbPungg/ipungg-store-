const $ = (s) => document.querySelector(s);
const rp = (n) => 'Rp' + Number(n).toLocaleString('id-ID');
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
let DATA = null, catSel = '', buyId = null;

async function api(url, body) {
  const r = await fetch(url, body ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) } : undefined);
  const j = await r.json().catch(() => ({ ok: false, error: 'Respon server tidak valid' }));
  if (!j.ok) throw new Error(j.error || 'Gagal');
  return j;
}
const pic = (src) => (src ? `<img src="${esc(src)}" alt="" loading="lazy" referrerpolicy="no-referrer">` : '<div class="ph"><i></i></div>');
const aLink = (t) => (!t ? '' : /^https?:\/\//.test(t) ? `<a href="${esc(t)}" target="_blank" rel="noopener">${esc(t)}</a>` : esc(t));
const showMsg = (el, text, ok) => { el.className = 'msg ' + (ok ? 'ok' : 'err'); el.textContent = text; };

/* ---------- muat data ---------- */
async function init() {
  const { site, plans, products, categories, botOnline } = await api('/api/public');
  DATA = { site, plans, products, categories: categories || [] };
  document.title = site.name + ' — Sewa Bot WhatsApp Otomatis';
  $('#siteName').textContent = site.name;
  $('#footerSite').textContent = site.name;
  $('#eyebrow').textContent = site.name.toUpperCase() + ' • DIGITAL SERVICE';
  if (site.logo) $('#brand').innerHTML = `<img src="${esc(site.logo)}" alt="" referrerpolicy="no-referrer"><span>${esc(site.name)}</span>`;
  const words = site.name.trim().split(/\s+/); $('#neon1').textContent = words.shift() || site.name; $('#neon2').textContent = words.join(' ');

  if (site.thumbnail) { $('#heroThumb').referrerPolicy = 'no-referrer'; $('#heroThumb').src = site.thumbnail; $('#heroThumb').alt = 'Banner ' + site.name; $('#heroThumbWrap').hidden = false; }

  const planImg = site.sewaImage || site.logo;
  $('#plans').innerHTML = plans.map((p, i) => `
    <label class="plan"><input type="radio" name="plan" value="${esc(p.id)}" ${i === 0 ? 'checked' : ''}>
      <span class="plan-pic">${pic(planImg)}${p.days >= 365 ? '<span class="tag">Hemat</span>' : ''}</span><span class="chk" aria-hidden="true">✓</span>
      <span class="plan-main"><b>${esc(p.name)}</b><small>${p.days} hari</small><strong>${rp(p.price)}</strong></span></label>`).join('')
    || '<div class="empty">Paket belum tersedia.</div>';

  renderCats(); renderProducts();

  $('#botDot').classList.toggle('on', botOnline);
  $('#botTxt').textContent = botOnline ? 'Bot online, pesanan diproses otomatis' : 'Bot sedang offline, pesanan tetap diproses saat bot kembali';
  renderContacts(site);
  setupAudio(site);
}

function renderCats() {
  const el = $('#categories'), cats = DATA.categories;
  if (!cats.length) { el.innerHTML = ''; return; }
  el.innerHTML = [{ id: '', name: 'Semua' }, ...cats].map((c) => `<button type="button" class="chip" data-cat="${esc(c.id)}" aria-pressed="${c.id === catSel}">${esc(c.name)}</button>`).join('');
}
function renderProducts() {
  const list = DATA.products.filter((p) => !catSel || p.categoryId === catSel);
  $('#products').innerHTML = list.length ? list.map((p) => `
    <article class="item">
      <div class="pic">${pic(p.image)}</div>
      <div class="body"><h3>${esc(p.name)}</h3><div class="price">${rp(p.price)}</div>
        <button class="btn" type="button" data-buy="${esc(p.id)}">Beli</button></div>
    </article>`).join('') : '<div class="empty">Belum ada produk di sini. Cek lagi nanti.</div>';
}
$('#categories').addEventListener('click', (e) => {
  const b = e.target.closest('[data-cat]'); if (!b) return;
  catSel = b.dataset.cat; renderCats(); renderProducts();
});

/* ---------- kontak ---------- */
const ICO_WA = '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/></svg>';
const ICO_TG = '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg>';
function renderContacts(site) {
  const items = [];
  const wa = (site.whatsapp || '').trim();
  if (/^https?:\/\//i.test(wa)) items.push({ name: 'WhatsApp', sub: 'Chat admin', href: wa, ico: ICO_WA });
  else {
    let n = wa.replace(/\D/g, ''); if (n.startsWith('0')) n = '62' + n.slice(1);
    if (n.length >= 8) items.push({ name: 'WhatsApp', sub: '+' + n, href: 'https://wa.me/' + n, ico: ICO_WA });
  }
  const tg = (site.telegram || '').trim();
  if (/^https?:\/\//i.test(tg)) items.push({ name: 'Telegram', sub: 'Chat admin', href: tg, ico: ICO_TG });
  else if (/^@?[A-Za-z0-9_]{4,}$/.test(tg)) items.push({ name: 'Telegram', sub: '@' + tg.replace('@', ''), href: 'https://t.me/' + tg.replace('@', ''), ico: ICO_TG });
  $('#contactGrid').innerHTML = items.length ? items.map((it) => `
    <a class="contact-card" href="${esc(it.href)}" target="_blank" rel="noopener">
      <span class="c-ico">${it.ico}</span><span class="c-txt"><b>${it.name}</b><small>${esc(it.sub)}</small></span><span class="c-go" aria-hidden="true">↗</span>
    </a>`).join('') : '<div class="empty">Kontak admin belum diatur.</div>';
  $('#contactNote').textContent = site.contactNote || 'Jam layanan mengikuti ketersediaan admin.';
}

/* ---------- overlay formulir ---------- */
function openModal(el) { el.classList.add('open'); el.style.display = ''; document.body.classList.add('lock'); }
function closeModals() {
  document.querySelectorAll('.modal').forEach((m) => { m.classList.remove('open'); m.style.display = ''; });
  document.body.classList.remove('lock');
}
const planOf = () => {
  const r = document.querySelector('input[name="plan"]:checked');
  return DATA && r ? DATA.plans.find((p) => p.id === r.value) : null;
};

// menggantikan fallback di index.html dengan versi lengkap (foto, judul, harga)
window.openSewaModal = function () {
  const plan = planOf();
  window.selectedPlan = plan ? plan.id : null;
  $('#sewaTitle').textContent = plan ? 'Sewa Bot ' + plan.name : 'Sewa Bot Sekarang';
  $('#sewaInfo').textContent = plan ? `${plan.days} hari • ${rp(plan.price)}` : 'Pilih paket terlebih dahulu';
  $('#sewaPic').innerHTML = pic(DATA && (DATA.site.sewaImage || DATA.site.logo));
  $('#sewaMsg').className = 'msg'; $('#sewaSubmit').disabled = false;
  openModal($('#sewaModal'));
  setTimeout(() => $('#f-name').focus(), 50);
  return false;
};

document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-buy]');
  if (b && DATA) {
    const p = DATA.products.find((x) => x.id === b.dataset.buy); if (!p) return;
    buyId = p.id;
    $('#buyTitle').textContent = p.name;
    $('#buyInfo').textContent = rp(p.price);
    $('#buyPic').innerHTML = pic(p.image);
    $('#buyMsg').className = 'msg'; $('#buyBtn').disabled = false;
    openModal($('#buyModal')); setTimeout(() => $('#b-name').focus(), 50);
  }
  if (e.target.classList && e.target.classList.contains('modal')) closeModals();
});
$('#sewaCancel').onclick = closeModals;
$('#buyCancel').onclick = closeModals;
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeModals(); });

$('#sewaForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = $('#sewaSubmit'), msg = $('#sewaMsg');
  const plan = window.selectedPlan || (planOf() || {}).id;
  if (!plan) return showMsg(msg, 'Pilih paket sewa terlebih dahulu', false);
  btn.disabled = true; msg.className = 'msg';
  try {
    const j = await api('/api/order/sewa', { planId: plan, name: $('#f-name').value, phone: $('#f-phone').value, link: $('#f-link').value, note: $('#f-note').value });
    location.href = `/order.html?id=${j.id}&t=${j.token}`;
  } catch (err) { showMsg(msg, err.message, false); btn.disabled = false; }
});
$('#buyForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = $('#buyBtn'), msg = $('#buyMsg');
  btn.disabled = true; msg.className = 'msg';
  try {
    const j = await api('/api/order/produk', { productId: buyId, name: $('#b-name').value, phone: $('#b-phone').value });
    location.href = `/order.html?id=${j.id}&t=${j.token}`;
  } catch (err) { showMsg(msg, err.message, false); btn.disabled = false; }
});

/* ---------- musik latar (diatur admin) ---------- */
function setupAudio(site) {
  if (!site.audio) return;
  const btn = $('#music'); btn.hidden = false;
  const a = new Audio(site.audio);
  a.loop = true; a.preload = 'none';
  a.volume = Math.min(1, Math.max(0, (site.audioVolume ?? 40) / 100));
  const KEY = 'ip_music';
  const pref = () => { try { return localStorage.getItem(KEY); } catch { return null; } };
  const save = (v) => { try { localStorage.setItem(KEY, v); } catch {} };
  const ui = () => {
    const on = !a.paused;
    btn.classList.toggle('on', on); btn.setAttribute('aria-pressed', String(on));
    btn.setAttribute('aria-label', on ? 'Matikan musik' : 'Putar musik');
  };
  const play = () => a.play().then(ui, ui);
  a.addEventListener('play', ui); a.addEventListener('pause', ui);
  btn.addEventListener('click', () => { if (a.paused) { save('on'); play(); } else { save('off'); a.pause(); } });
  if (pref() !== 'off') {
    play(); // browser bisa menolak sebelum ada sentuhan pertama
    const evs = ['pointerdown', 'keydown', 'touchstart'];
    const first = (e) => {
      if (btn.contains(e.target)) return;
      evs.forEach((ev) => document.removeEventListener(ev, first));
      if (a.paused && pref() !== 'off') play();
    };
    evs.forEach((ev) => document.addEventListener(ev, first, { passive: true }));
  }
  let was = false;
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) { was = !a.paused; a.pause(); } else if (was) { play(); was = false; }
  });
}

/* ---------- layar loading: tampil minimal 1,6 detik supaya neonnya terlihat ---------- */
const T0 = performance.now();
function hideLoader() {
  const l = $('#loader'); if (!l || l.classList.contains('done')) return;
  l.classList.add('done'); l.setAttribute('aria-hidden', 'true');
  document.documentElement.classList.remove('is-loading');
  setTimeout(() => l.remove(), 800);
}
init()
  .catch((e) => { $('#botTxt').textContent = 'Gagal memuat data: ' + e.message; })
  .finally(() => setTimeout(hideLoader, Math.max(0, 1600 - (performance.now() - T0))));
