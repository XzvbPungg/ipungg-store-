const $ = (s, r = document) => r.querySelector(s);
const rp = (n) => 'Rp' + Number(n || 0).toLocaleString('id-ID');
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const dt = (ms) => (ms ? new Date(ms).toLocaleString('id-ID', { dateStyle: 'medium', timeStyle: 'short' }) : '-');
const root = $('#root');
let tab = 'pesanan', S = { siteName: 'Ipungg Store', logo: '', thumbnail: '' };

const TABS = [['pesanan', 'Pesanan'], ['produk', 'Produk'], ['kategori', 'Kategori'], ['paket', 'Paket sewa bot'], ['pengaturan', 'Pengaturan web'], ['backup', 'Backup Telegram'], ['apikey', 'API key'], ['info', 'Saluran'], ['database', 'Database'], ['diagnosa', 'Diagnosa'], ['akun', 'Akun']];

async function api(url, method = 'GET', body) {
  const opt = { method, headers: { 'Content-Type': 'application/json' } };
  if (method !== 'GET') opt.body = JSON.stringify(body || {});
  const r = await fetch('/api/admin' + url, opt);
  const j = await r.json().catch(() => ({ ok: false, error: 'Respon tidak valid' }));
  if (r.status === 401) { loginView(); throw new Error('Sesi habis, masuk lagi'); }
  if (!j.ok) throw new Error(j.error || 'Gagal');
  return j;
}
function toast(t, ok = true) {
  const el = document.createElement('div'); el.className = 'toast ' + (ok ? 'ok' : 'err'); el.textContent = t;
  document.body.append(el); setTimeout(() => el.remove(), 2800);
}
const run = (fn) => async (...a) => { try { await fn(...a); } catch (e) { toast(e.message, false); } };
const val = (f, n) => f.elements[n].value;

/* ---------- gambar: kecilkan dulu supaya foto HP tidak kena batas 2 MB ---------- */
function prep(file, max, png) {
  return new Promise((ok, no) => {
    const url = URL.createObjectURL(file), im = new Image();
    im.onload = () => {
      const k = Math.min(1, max / Math.max(im.width, im.height));
      const c = document.createElement('canvas');
      c.width = Math.round(im.width * k); c.height = Math.round(im.height * k);
      const x = c.getContext('2d');
      if (!png) { x.fillStyle = '#000'; x.fillRect(0, 0, c.width, c.height); }
      x.drawImage(im, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      ok(c.toDataURL(png ? 'image/png' : 'image/jpeg', 0.86));
    };
    im.onerror = () => no(new Error('File bukan gambar yang valid'));
    im.src = url;
  });
}
const SIZE = { logo: 512, thumbnail: 1600, sewa: 900, produk: 900 };

async function onFile(e) {
  const inp = e.target;
  if (!inp.matches || !inp.matches('input[type=file][data-up]')) return;
  const f = inp.files[0]; if (!f) return;
  const kind = inp.dataset.up;
  const data = await prep(f, SIZE[kind], kind === 'logo');
  const r = await api('/upload/' + kind, 'POST', { data });
  if (kind === 'produk') {
    const box = inp.closest('.imgfield');
    box.querySelector('input[name=image]').value = r.url;
    setPreview(box, r.url);
    toast('Foto terunggah. Klik Simpan produk.');
  } else { toast('Gambar diperbarui'); shell(); }
}

const SETKEY = { logo: 'logo', thumbnail: 'thumbnail', sewa: 'sewaImage' };
const checkImg = (url) => new Promise((ok, no) => {
  const im = new Image(); const t = setTimeout(() => no(new Error('Link terlalu lama dibuka')), 10000);
  im.onload = () => { clearTimeout(t); ok(); };
  im.onerror = () => { clearTimeout(t); no(new Error('Link bukan gambar / tidak bisa dibuka. Pakai link langsung ke gambar (.jpg .png .webp).')); };
  im.referrerPolicy = 'no-referrer'; im.src = url;
});
const setPreview = (box, url) => {
  const el = box.querySelector('.thumbp, .thumbph');
  el.outerHTML = url ? `<img class="thumbp" src="${esc(url)}" alt="" referrerpolicy="no-referrer">` : '<div class="thumbph ph"><i></i></div>';
};
async function onClick(e) {
  const use = e.target.closest('[data-useurl]'), clr = e.target.closest('[data-clearimg]'), clrSet = e.target.closest('[data-clearset]');
  if (use) {
    const kind = use.dataset.useurl, inp = use.parentElement.querySelector('input[data-url]'), url = inp.value.trim();
    if (!/^https:\/\//i.test(url)) throw new Error('Link harus diawali https://');
    use.disabled = true;
    try { await checkImg(url); } finally { use.disabled = false; }
    if (kind === 'produk') {
      const box = use.closest('.imgfield'); box.querySelector('input[name=image]').value = url; setPreview(box, url); inp.value = '';
      toast('Link dipakai. Klik Simpan produk.');
    } else { await api('/settings', 'PUT', { [SETKEY[kind]]: url }); toast('Gambar diperbarui'); shell(); }
  } else if (clr) {
    const box = clr.closest('.imgfield'); box.querySelector('input[name=image]').value = ''; setPreview(box, ''); toast('Foto dihapus. Klik Simpan.');
  } else if (clrSet) {
    await api('/settings', 'PUT', { [SETKEY[clrSet.dataset.clearset]]: '' }); toast('Gambar dihapus'); shell();
  }
}

/* ---------- login ---------- */
function loginView() {
  root.innerHTML = `<div class="login"><form class="card" id="lf">
    <h3>Masuk dashboard</h3>
    <label for="u">Username</label><input id="u" autocomplete="username" required>
    <label for="p">Password</label><input id="p" type="password" autocomplete="current-password" required>
    <button class="btn" type="submit">Masuk</button><div class="msg" id="lm" role="alert"></div></form></div>`;
  $('#lf').onsubmit = async (e) => {
    e.preventDefault();
    try {
      const r = await fetch('/api/admin/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: $('#u').value, password: $('#p').value }) });
      const j = await r.json(); if (!j.ok) throw new Error(j.error); shell();
    } catch (er) { $('#lm').className = 'msg err'; $('#lm').textContent = er.message; }
  };
}

/* ---------- kerangka: menu tombol berjajar ke bawah di kiri ---------- */
async function shell() {
  try { await api('/me'); } catch { return; }
  try { S = await api('/settings'); } catch {}
  const label = (TABS.find((t) => t[0] === tab) || [])[1] || '';
  const logo = S.logo ? `<img src="${esc(S.logo)}" alt="">` : '';
  root.innerHTML = `<div class="adm">
    <div class="mbar"><button id="menu" aria-label="Buka menu" aria-expanded="false">☰</button>${logo}<b>${esc(label)}</b></div>
    <div class="scrim" id="scrim"></div>
    <aside class="side" id="side" aria-label="Menu admin">
      ${S.thumbnail ? `<img class="sbanner" src="${esc(S.thumbnail)}" alt="Banner">` : '<div class="sbanner-ph"></div>'}
      <div class="slogo">${S.logo ? `<img src="${esc(S.logo)}" alt="">` : '<i></i>'}<b>${esc(S.siteName)}</b></div>
      <nav class="snav">${TABS.map(([k, n]) => `<button data-t="${k}" class="${k === tab ? 'on' : ''}">${n}</button>`).join('')}</nav>
      <button class="btn ghost sout" id="out">Keluar</button>
    </aside>
    <main class="main" id="view"></main></div>`;
  const side = $('#side'), scrim = $('#scrim'), menu = $('#menu');
  const setOpen = (o) => { side.classList.toggle('open', o); scrim.classList.toggle('open', o); menu.setAttribute('aria-expanded', String(o)); };
  menu.onclick = () => setOpen(!side.classList.contains('open'));
  scrim.onclick = () => setOpen(false);
  document.onkeydown = (e) => { if (e.key === 'Escape') setOpen(false); };
  root.querySelectorAll('[data-t]').forEach((b) => b.onclick = () => { tab = b.dataset.t; shell(); });
  $('#out').onclick = async () => { await fetch('/api/admin/logout', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' }); loginView(); };
  $('#view').addEventListener('change', run(onFile));
  $('#view').addEventListener('click', run(onClick));
  views[tab]().catch((e) => toast(e.message, false));
}
const view = (h) => { $('#view').innerHTML = h; return $('#view'); };

const views = {
  async pesanan() {
    const [ov, { orders }] = await Promise.all([api('/overview'), api('/orders')]);
    const stat = (o) => `<span class="pill ${o.status}">${o.status === 'paid' ? 'Lunas' : o.status === 'pending' ? 'Menunggu' : 'Kedaluwarsa'}</span>` +
      (o.status === 'paid' ? `<span class="pill ${o.fulfil === 'done' ? 'paid' : o.fulfil}" title="${esc(o.error)}">${o.fulfil === 'done' ? 'Terkirim' : o.fulfil === 'error' ? 'Gagal' : 'Proses'}</span>` : '');
    const v = view(`<div class="bar"><h2>Informasi pembelian</h2><button class="btn ghost sm" id="rf">Muat ulang</button></div>
      <div class="stats">
        <div class="stat"><span>Pendapatan</span><b>${rp(ov.revenue)}</b></div>
        <div class="stat"><span>Hari ini</span><b>${rp(ov.todayRevenue)}</b></div>
        <div class="stat"><span>Pesanan lunas</span><b>${ov.totalOrders}</b></div>
        <div class="stat"><span>Bot</span><b style="color:${ov.botOnline ? 'var(--ok)' : 'var(--red2)'}">${ov.botOnline ? 'Online' : 'Offline'}</b></div></div>
      ${ov.needAttention ? `<div class="msg err">${ov.needAttention} pesanan sudah dibayar tapi belum terproses. Klik Proses ulang.</div>` : ''}
      <div class="olist">${orders.length ? orders.map((o) => `<article class="ocard">
        <div class="ohead"><b>${esc(o.buyerName)}</b><span class="pills">${stat(o)}</span></div>
        <dl class="odl">
          <div><dt>Harga</dt><dd>${rp(o.amount)}</dd></div>
          <div><dt>No WhatsApp</dt><dd><a href="https://wa.me/${esc(o.buyerPhone)}" target="_blank" rel="noopener">${esc(o.buyerPhone)}</a></dd></div>
          <div><dt>Produk</dt><dd>${esc(o.itemName)}</dd></div>
          <div><dt>Tanggal</dt><dd>${dt(o.paidAt || o.createdAt)}</dd></div>
        </dl>
        ${o.groupLink ? `<p class="hint" style="word-break:break-all">Grup: ${esc(o.groupLink)}</p>` : ''}
        ${o.note ? `<p class="hint">Catatan: ${esc(o.note)}</p>` : ''}
        ${o.status === 'paid' && o.fulfil !== 'done' ? `<button class="btn sm" style="margin-top:12px" data-retry="${esc(o.id)}">Proses ulang</button>${o.error ? `<p class="hint">${esc(o.error)}</p>` : ''}` : ''}
      </article>`).join('') : '<div class="card" style="text-align:center;color:var(--mute)">Belum ada pesanan</div>'}</div>`);
    $('#rf', v).onclick = () => shell();
    v.querySelectorAll('[data-retry]').forEach((b) => b.onclick = run(async () => {
      b.disabled = true; const r = await api(`/orders/${b.dataset.retry}/retry`, 'POST', {});
      toast(r.fulfil === 'done' ? 'Berhasil diproses' : 'Gagal: ' + r.error, r.fulfil === 'done'); shell();
    }));
  },

  async produk() {
    const [{ products }, { categories }] = await Promise.all([api('/products'), api('/categories')]);
    const catName = (id) => (categories.find((c) => c.id === id) || {}).name || 'Tanpa kategori';
    const imgField = (url) => `<div class="imgfield"><label>Foto produk</label><div class="imgrow">
      ${url ? `<img class="thumbp" src="${esc(url)}" alt="" referrerpolicy="no-referrer">` : '<div class="thumbph ph"><i></i></div>'}
      <div><input type="file" accept="image/*" data-up="produk">
        <div class="urlrow"><input type="url" inputmode="url" placeholder="atau tempel link gambar https://..." data-url="produk"><button class="btn sm" type="button" data-useurl="produk">Pakai</button></div>
        <p class="hint">Unggah file, atau tempel link langsung ke gambar.</p>
        <button class="btn sm ghost" type="button" data-clearimg style="margin-top:8px">Hapus foto</button></div></div>
      <input type="hidden" name="image" value="${esc(url)}"></div>`;
    const catField = (cur) => `<label>Kategori</label><select name="categoryId"><option value="">Tanpa kategori</option>${categories.map((c) => `<option value="${esc(c.id)}" ${c.id === cur ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select>`;
    const form = (p = {}) => `<label>Nama produk</label><input name="name" value="${esc(p.name)}" required maxlength="80">
      ${imgField(p.image || '')}${catField(p.categoryId)}
      <div class="row2"><div><label>Harga (Rp)</label><input name="price" type="number" min="1" value="${p.price ?? ''}" required></div>
      <div><label>Link MediaFire</label><input name="url" value="${esc(p.url)}" placeholder="https://www.mediafire.com/file/..." required></div></div>
      <label>Catatan produk (ikut dikirim ke pembeli setelah bayar)</label><textarea name="note" maxlength="400">${esc(p.note)}</textarea>
      <label style="display:flex;gap:8px;align-items:center"><input type="checkbox" name="active" style="width:auto" ${p.active === false ? '' : 'checked'}> Tampilkan di toko</label>`;
    const read = (f) => ({ name: val(f, 'name'), image: val(f, 'image'), categoryId: val(f, 'categoryId'), price: val(f, 'price'), url: val(f, 'url'), note: val(f, 'note'), active: f.elements.active.checked });
    const v = view(`<h2>Produk</h2>
      ${categories.length ? '' : '<p style="margin-top:6px">Mau mengelompokkan produk? Buat kategori dulu di menu <b>Kategori</b>.</p>'}
      <form class="card" id="np" style="margin:16px 0"><h3>Tambah produk</h3>${form()}<button class="btn" type="submit">Simpan produk</button></form>
      <h3 style="margin:22px 0 12px">Daftar produk (${products.length})</h3>
      <div class="stack">${products.length ? products.map((p) => `<details class="card pcard">
        <summary class="psum">${p.image ? `<img class="pthumb" src="${esc(p.image)}" alt="">` : '<div class="pthumb ph"><i></i></div>'}
          <div class="pinfo"><b>${esc(p.name)}</b><span>${rp(p.price)} · ${esc(catName(p.categoryId))}${p.active === false ? ' · Disembunyikan' : ''}</span></div><span class="pedit">Edit</span></summary>
        <form class="pform" data-id="${esc(p.id)}">${form(p)}
          <div style="display:flex;gap:8px;margin-top:16px"><button class="btn sm" type="submit">Simpan perubahan</button><button class="btn sm danger" type="button" data-del>Hapus produk</button></div></form></details>`).join('')
        : '<div class="card" style="text-align:center;color:var(--mute)">Belum ada produk.</div>'}</div>`);
    $('#np', v).onsubmit = run(async (e) => { e.preventDefault(); await api('/products', 'POST', read(e.target)); toast('Produk ditambahkan'); shell(); });
    v.querySelectorAll('form[data-id]').forEach((f) => {
      f.onsubmit = run(async (e) => { e.preventDefault(); await api('/products/' + f.dataset.id, 'PUT', read(f)); toast('Perubahan tersimpan'); shell(); });
      $('[data-del]', f).onclick = run(async () => { if (confirm('Hapus produk ini beserta fotonya?')) { await api('/products/' + f.dataset.id, 'DELETE'); toast('Produk dihapus'); shell(); } });
    });
  },

  async kategori() {
    const { categories } = await api('/categories');
    const v = view(`<h2>Kategori produk</h2>
      <form class="card" id="nc" style="margin:16px 0"><h3>Tambah kategori</h3>
        <input name="name" required minlength="2" maxlength="30" placeholder="Contoh: Script Bot">
        <button class="btn" type="submit">Tambah kategori</button></form>
      <div class="stack">${categories.length ? categories.map((c) => `<form class="card" data-id="${esc(c.id)}">
        <label style="margin-top:0">Nama kategori</label><input name="name" value="${esc(c.name)}" required minlength="2" maxlength="30">
        <p class="hint">${c.count} produk di kategori ini</p>
        <div style="display:flex;gap:8px;margin-top:14px"><button class="btn sm" type="submit">Simpan nama</button><button class="btn sm danger" type="button" data-del data-name="${esc(c.name)}">Hapus</button></div></form>`).join('')
        : '<div class="card" style="text-align:center;color:var(--mute)">Belum ada kategori.</div>'}</div>`);
    $('#nc', v).onsubmit = run(async (e) => { e.preventDefault(); await api('/categories', 'POST', { name: val(e.target, 'name') }); toast('Kategori ditambahkan'); shell(); });
    v.querySelectorAll('form[data-id]').forEach((f) => {
      f.onsubmit = run(async (e) => { e.preventDefault(); await api('/categories/' + f.dataset.id, 'PUT', { name: val(f, 'name') }); toast('Nama diubah'); shell(); });
      $('[data-del]', f).onclick = run(async (e) => {
        if (confirm(`Hapus kategori "${e.target.dataset.name}"? Produk di dalamnya tidak ikut terhapus, hanya jadi tanpa kategori.`)) {
          await api('/categories/' + f.dataset.id, 'DELETE'); toast('Kategori dihapus'); shell();
        }
      });
    });
  },

  async paket() {
    const { plans } = await api('/plans');
    const v = view(`<h2>Paket sewa bot</h2><p style="margin:6px 0 16px">Ubah harga atau durasi. Langsung tampil di toko.</p><div class="stack">${plans.map((p) => `
      <form class="card" data-id="${esc(p.id)}"><div class="row2"><div><label>Nama</label><input name="name" value="${esc(p.name)}"></div>
      <div><label>Durasi (hari)</label><input name="days" type="number" min="1" value="${p.days}"></div></div>
      <label>Harga (Rp)</label><input name="price" type="number" min="1" value="${p.price}"><button class="btn sm" style="margin-top:14px" type="submit">Simpan</button></form>`).join('')}</div>`);
    v.querySelectorAll('form').forEach((f) => f.onsubmit = run(async (e) => { e.preventDefault(); await api('/plans/' + f.dataset.id, 'PUT', { name: val(f, 'name'), days: val(f, 'days'), price: val(f, 'price') }); toast('Tersimpan'); }));
  },

  async pengaturan() {
    const s = S;
    const block = (kind, label, url, wide, hint) => `<div class="card"><h3>${label}</h3>
      ${url ? `<img class="${wide ? 'banprev' : 'thumbp'}" src="${esc(url)}" alt="" referrerpolicy="no-referrer" ${wide ? '' : 'style="width:96px;height:96px;margin-bottom:8px"'}>` : '<p class="hint" style="margin:0 0 8px">Belum ada gambar</p>'}
      <label style="margin-top:0">Unggah file (dokumen / galeri)</label><input type="file" accept="image/*" data-up="${kind}">
      <label>atau pakai link gambar</label><div class="urlrow"><input type="url" inputmode="url" placeholder="https://..." data-url="${kind}"><button class="btn sm" type="button" data-useurl="${kind}">Pakai</button></div>
      <p class="hint">${hint}</p>
      ${url ? `<button class="btn sm danger" type="button" data-clearset="${kind}" style="margin-top:10px">Hapus gambar</button>` : ''}</div>`;
    const v = view(`<h2>Pengaturan web</h2>
      <form class="card" id="sf" style="margin:16px 0"><label style="margin-top:0">Nama web</label><input name="siteName" value="${esc(s.siteName)}" required maxlength="40">
        <label>Batas waktu bayar (menit)</label><input name="ttl" type="number" min="5" max="120" value="${s.orderTtlMinutes}">
        <label style="display:flex;gap:10px;align-items:center;margin-top:18px"><input type="checkbox" name="maintenance" style="width:auto" ${s.maintenance ? 'checked' : ''}> Maintenance website</label>
        <p class="hint">ON: halaman toko dan pembelian publik ditutup. Dashboard admin, koneksi bot, webhook pembayaran, dan notifikasi saluran tetap aktif.</p>
        <button class="btn sm" style="margin-top:16px" type="submit">Simpan</button></form>
      <div class="card" style="margin:14px 0"><h3>Notifikasi WhatsApp Channel</h3>
        <label style="margin-top:0">ID / JID Saluran</label>
        <input id="channelIdWeb" value="${esc(s.channelId || '')}" placeholder="contoh: 120363xxxxxxxx@newsletter">
        <label>Link Saluran</label>
        <input id="channelLinkWeb" value="${esc(s.channelLink || '')}" placeholder="https://whatsapp.com/channel/...">
        <p class="hint">Isi <b>ID/JID saluran</b> untuk tujuan kirim. Link hanya untuk ditampilkan. Notifikasi pembelian <b>sewa bot dan produk tambahan</b> dikirim ke saluran ini. Kartu transaksi otomatis memakai nama + logo dari profil website.</p>
        <button class="btn sm" type="button" id="saveChannelWeb">Simpan Saluran</button>
      </div>
      <div class="stack">
        ${block('logo', 'Logo web', s.logo, false, 'Tampil di bar atas toko dan menu admin.')}
        ${block('thumbnail', 'Banner / thumbnail web', s.thumbnail, true, 'Tampil jelas di paling atas toko (disarankan lebar, rasio 16:7).')}
        ${block('sewa', 'Foto sewa bot', s.sewaImage, false, 'Tampil di semua kartu paket sewa dan di formulir sewa. Kalau kosong, memakai logo web.')}
      </div>
      <div class="card" style="margin-top:14px"><h3>Audio website</h3>
        ${s.audio ? `<audio controls preload="none" src="${esc(s.audio)}" style="width:100%;margin-bottom:12px"></audio>` : '<p class="hint" style="margin:0 0 12px">Belum ada audio.</p>'}
        <form id="audioForm">
          <label style="display:flex;gap:8px;align-items:center;margin-top:0"><input type="checkbox" name="audioOn" style="width:auto" ${s.audioOn ? 'checked' : ''}> Putar musik di toko</label>
          <label>Volume</label><div style="display:flex;gap:12px;align-items:center"><input type="range" name="audioVolume" min="0" max="100" value="${s.audioVolume}" style="padding:0" oninput="this.nextElementSibling.textContent=this.value+'%'"><output style="min-width:3.2em;text-align:right">${s.audioVolume}%</output></div>
          <button class="btn sm" style="margin-top:14px" type="submit">Simpan audio</button>
        </form>
        <label>Upload file audio (MP3 / M4A / OGG / WAV, maksimal 10 MB)</label>
        <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
          <input id="audioFile" type="file" accept=".mp3,.m4a,.ogg,.wav,audio/*" style="max-width:100%">
          <button class="btn sm" type="button" id="audioUpload">Upload Audio</button>
        </div>
        <label>Atau gunakan URL audio</label>
        <div style="display:flex;gap:8px;align-items:center"><input name="audioUrl" value="${/^https?:\/\//i.test(s.audio || '') ? esc(s.audio) : ''}" placeholder="https://domain.com/musik.mp3"><button class="btn sm" type="button" id="audioUrlSave">Pakai URL</button></div>
        <p class="hint">Upload lokal disimpan di folder uploads hosting. Kalau memakai hosting sementara, pastikan folder data/uploads tidak dihapus saat redeploy.</p>
        ${s.audio ? '<button class="btn sm danger" style="margin-top:12px" id="audioDel" type="button">Hapus URL audio</button>' : ''}
        <p class="hint">Musik diputar berulang. Browser baru mengizinkan suara setelah pengunjung menyentuh layar, dan pengunjung bisa mematikannya lewat tombol speaker di pojok kanan bawah.</p>
      </div>`);
    $('#sf', v).onsubmit = run(async (e) => { e.preventDefault(); const f = e.target; await api('/settings', 'PUT', { siteName: val(f, 'siteName'), orderTtlMinutes: val(f, 'ttl'), maintenance: f.elements.maintenance.checked }); toast(f.elements.maintenance.checked ? 'Maintenance website ON' : 'Maintenance website OFF'); shell(); });
    $('#saveChannelWeb', v).onclick = run(async () => { const id = String($('#channelIdWeb', v)?.value || '').trim(); const link = String($('#channelLinkWeb', v)?.value || '').trim(); if (!id) throw new Error('ID/JID saluran wajib diisi'); await api('/settings', 'PUT', { channelId: id, channelLink: link }); toast('ID saluran tersimpan'); shell(); });
    $('#audioForm', v).onsubmit = run(async (e) => {
      e.preventDefault(); const f = e.target;
      await api('/settings', 'PUT', { audioOn: f.elements.audioOn.checked, audioVolume: val(f, 'audioVolume') }); toast('Audio tersimpan');
    });
    $('#audioUrlSave', v).onclick = run(async () => {
      const url = String($('input[name="audioUrl"]', v)?.value || '').trim();
      if (!url || !/^https:\/\//i.test(url)) throw new Error('URL audio harus diawali https://');
      await api('/settings', 'PUT', { audioUrl: url }); toast('URL audio tersimpan'); shell();
    });
    $('#audioUpload', v).onclick = run(async () => {
      const input = $('#audioFile', v);
      const file = input && input.files && input.files[0];
      if (!file) throw new Error('Pilih file audio dahulu');
      if (file.size > 10 * 1024 * 1024) throw new Error('Ukuran audio maksimal 10 MB');
      const mimeByExt = { mp3: 'audio/mpeg', m4a: 'audio/mp4', ogg: 'audio/ogg', wav: 'audio/wav' };
      const ext = String(file.name.split('.').pop() || '').toLowerCase();
      const mime = mimeByExt[ext] || file.type;
      if (!mime || !/^audio\//i.test(mime)) throw new Error('Format harus MP3, M4A, OGG, atau WAV');
      const response = await fetch('/api/admin/audio', {
        method: 'POST',
        headers: { 'Content-Type': mime },
        body: file
      });
      const result = await response.json().catch(() => ({ ok: false, error: 'Respon server tidak valid' }));
      if (response.status === 401) { loginView(); throw new Error('Sesi habis, masuk lagi'); }
      if (!response.ok || !result.ok) throw new Error(result.error || 'Upload audio gagal');
      toast('Audio berhasil diunggah'); shell();
    });
    const del = $('#audioDel', v);
    if (del) del.onclick = run(async () => { if (confirm('Hapus audio website?')) { await api('/audio', 'DELETE'); toast('Audio dihapus'); shell(); } });
  },

  async backup() {
    const s = S;
    const v = view(`<h2>Backup Telegram</h2>
      <p style="margin:6px 0 16px">Backup otomatis data toko setiap <b>1 jam</b> ke Telegram.</p>
      <form class="card" id="tf">
        <label>Bot Token Telegram</label>
        <input name="token" type="password" placeholder="123456:AA..." autocomplete="off">
        <p class="hint">Tempel token bot Telegram. Token yang tersimpan tidak ditampilkan penuh.</p>
        <label>Chat ID tujuan</label>
        <input name="chatId" value="${esc(s.telegramBackupChatId || '')}" placeholder="contoh: -1001234567890">
        <p class="hint">Telegram tetap membutuhkan Chat ID tujuan. Bisa grup, channel, atau chat pribadi tempat bot sudah ditambahkan.</p>
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:14px">
          <button class="btn sm" type="submit">Simpan Backup</button>
          <button class="btn ghost sm" type="button" id="testBackup">Backup Sekarang</button>
        </div>
        <p class="hint" style="margin-top:12px">Isi token + Chat ID sekali. Setelah tersimpan, server akan mengirim file JSON backup otomatis setiap jam. Data order/pembeli, produk, kategori, paket, pengaturan, dan snapshot pengunjung aktif ikut dicadangkan; secret internal tidak dikirim.</p>
      </form>`);
    $('#tf', v).onsubmit = run(async (e) => {
      e.preventDefault(); const f=e.target; const token=String(val(f,'token')||'').trim(); const chatId=String(val(f,'chatId')||'').trim();
      const body={telegramBackupChatId:chatId}; if(token) body.telegramBackupToken=token;
      await api('/settings','PUT',body); toast('Pengaturan backup tersimpan'); shell();
    });
    $('#testBackup', v).onclick = run(async () => { await api('/telegram-backup/test','POST',{}); toast('Backup Telegram terkirim'); });
  },

  async apikey() {
    const s = S; const p = s.payment;
    const opt = (v, cur, l) => `<option value="${v}" ${cur === v ? 'selected' : ''}>${l || v}</option>`;
    const v = view(`<h2>API key</h2>
      <div class="card" id="pairCard" style="margin-top:16px"><h3>Sambungkan bot (tanpa API key)</h3>
        <p style="font-size:.92rem">Untuk toko dan bot di <b>dua server berbeda</b>. Pasang plugin <b>ipungg-link</b> di server bot, lalu kirim perintah di bawah ke bot dari <b>nomor owner</b> (chat pribadi). Selesai: tidak perlu mengisi API key atau URL.</p>
        <label>Alamat toko ini (yang akan dilihat bot)</label><input id="pairOrigin" value="${esc(location.origin)}">
        <p class="hint">Harus bisa dibuka dari server bot, mis. <code class="k">http://panel1.warhead1.shop:3155</code>. Kalau toko sudah pakai domain, pakai alamat domain itu.</p>
        <button class="btn sm" type="button" id="pairMake" style="margin-top:12px">Buat perintah sambung</button>
        <pre class="pre" id="pairOut" hidden></pre>
        <button class="btn ghost sm" type="button" id="pairCopy" hidden style="margin-top:10px">Salin perintah</button>
      </div>
      <form class="card" id="bf" style="margin-top:16px"><h3>Status bot WhatsApp</h3>
        <p>Status: <b id="botState" style="color:var(--mute)">memeriksa…</b></p>
        <p class="hint" id="botWhy"></p>
        <button class="btn ghost sm" type="button" id="botTest" style="margin-top:8px">Tes koneksi bot</button>
        <details style="margin-top:12px"><summary style="cursor:pointer;color:var(--mute);font-weight:600">Mode lanjutan (dua server dengan API, tidak perlu untuk sambung otomatis)</summary>
        <label>API key bot</label><p class="hint">Sekarang: <code class="k">${esc(s.botApiKeyMasked)}</code></p>
        <input name="botApiKey" placeholder="Kosongkan jika tidak diganti">
        <label>URL server bot (isi jika web &amp; bot beda server)</label><input name="botUrl" value="${esc(s.botUrl)}" placeholder="http://domainpanel:PORT">
        <p class="hint">Mode sekarang: <b>${esc(s.botMode)}</b>. Kosongkan URL jika web satu server dengan bot.</p>
        </details>
        <label>Nomor owner (notifikasi pesanan masuk)</label><input name="ownerPhone" value="${esc(s.ownerPhone)}" placeholder="6282125774233">
        <button class="btn sm" style="margin-top:14px" type="submit">Simpan</button></form>
      <form class="card" id="pf" style="margin-top:14px"><h3>Payment gateway (AustinPay)</h3>
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:6px"><button class="btn sm" type="button" id="payPreset">Pakai pengaturan AustinPay</button><button class="btn ghost sm" type="button" id="payIp">Cek IP server</button></div>
        <p class="hint" id="payIpOut">AustinPay mewajibkan IP server ini didaftarkan di <b>austinx.cloud/profile</b> &gt; Whitelist IP. Klik "Cek IP server" untuk melihat IP-nya.</p>
        ${s.lastPaymentError ? `<div class="msg err" style="margin:0 0 12px">Error terakhir (${dt(s.lastPaymentError.at)}): ${esc(s.lastPaymentError.msg)}</div>` : ''}
        <label style="margin-top:0">API key payment</label><p class="hint">Sekarang: <code class="k">${esc(p.apikeyMasked || 'belum diisi')}</code></p>
        <input name="apikey" placeholder="Kosongkan jika tidak diganti" autocomplete="off">
        <label>API Secret (HMAC, opsional)</label><p class="hint">Sekarang: <code class="k">${esc(p.apiSecretMasked || 'tidak dipakai')}</code>. Isi hanya kalau kamu membuat API Secret di Profil AustinPay.</p>
        <input name="apiSecret" placeholder="Kosongkan jika tidak diganti" autocomplete="off">
        <p class="hint" style="margin-top:14px">URL webhook untuk diisi di gateway: <code class="k">${esc(location.origin + s.webhookPath)}</code></p>
        <div style="margin-top:14px"><button class="btn ghost sm" type="button" id="payTest">Tes buat transaksi</button>
          <p class="hint">Simpan pengaturan dulu, baru tes. Ini membuat 1 QR uji (sebesar paket termurah) yang kedaluwarsa sendiri dalam 5 menit, jangan dibayar. Hasilnya menampilkan penyebab kalau gagal.</p>
          <pre class="pre" id="payOut" hidden></pre></div>
        <details style="margin-top:16px"><summary style="cursor:pointer;color:var(--red2);font-weight:700">Pengaturan endpoint (sesuaikan dengan dokumentasi gateway)</summary>
          <div class="row2"><div><label>Base URL</label><input name="baseUrl" value="${esc(p.baseUrl)}"></div>
          <div><label>Method buat transaksi</label><select name="method">${opt('POST', p.method)}${opt('GET', p.method)}</select></div>
          <div><label>Method cek status</label><select name="statusMethod">${opt('GET', p.statusMethod || p.method)}${opt('POST', p.statusMethod || p.method)}</select></div>
          <div><label>Path buat transaksi</label><input name="createPath" value="${esc(p.createPath)}"></div>
          <div><label>Path cek status (<code>{id}</code> = ID transaksi)</label><input name="statusPath" value="${esc(p.statusPath)}"></div>
          <div><label>Cara kirim API key</label><select name="authMode">${opt('query', p.authMode, 'Di URL (?apikey=)')}${opt('body', p.authMode, 'Di body')}${opt('header', p.authMode, 'Di header')}${opt('bearer', p.authMode, 'Bearer token')}</select></div>
          <div><label>Nama field API key</label><input name="keyField" value="${esc(p.keyField)}"></div>
          <div><label>Format body</label><select name="bodyFormat">${opt('json', p.bodyFormat)}${opt('form', p.bodyFormat)}</select></div>
          <div><label>Field nominal</label><input name="amountField" value="${esc(p.amountField)}"></div>
          <div><label>Field ID order (kosongkan jika gateway tidak memakainya)</label><input name="refField" value="${esc(p.refField)}"></div>
          <div><label>Status lunas (pisah koma)</label><input name="paidValues" value="${esc(p.paidValues)}"></div>
          <div><label>Status gagal/expired</label><input name="expiredValues" value="${esc(p.expiredValues)}"></div></div>
          <h3 style="margin-top:18px;font-size:1rem">Lokasi data di respon gateway</h3>
          <div class="row2">${[['trxId', 'ID transaksi'], ['qrImage', 'Gambar QR'], ['qrString', 'String QRIS'], ['payUrl', 'Link bayar'], ['expired', 'Waktu expired'], ['payAmount', 'Nominal yang harus dibayar'], ['status', 'Status']].map(([k, l]) => `<div><label>${l}</label><input name="map_${k}" value="${esc(p.map[k])}"></div>`).join('')}</div>
        </details>
        <button class="btn sm" style="margin-top:16px" type="submit">Simpan payment</button></form>`);
    const testBot = run(async () => {
      const b = $('#botTest', v); b.disabled = true; $('#botState', v).textContent = 'memeriksa…'; $('#botState', v).style.color = 'var(--mute)';
      try {
        const r = await api('/bot-status');
        const okk = r.state === 'online';
        $('#botState', v).textContent = okk ? 'Terhubung' : 'Belum terhubung';
        $('#botState', v).style.color = okk ? 'var(--ok)' : 'var(--red2)';
        $('#botWhy', v).textContent = r.msg;
      } finally { b.disabled = false; }
    });
    $('#botTest', v).onclick = testBot; testBot();
    $('#pairMake', v).onclick = run(async () => {
      const r = await api('/pair-code', 'POST', { origin: $('#pairOrigin', v).value });
      const o = $('#pairOut', v); o.hidden = false; o.textContent = r.command; $('#pairCopy', v).hidden = false;
      toast('Perintah dibuat. Kirim ke bot dari nomor owner.');
    });
    $('#pairCopy', v).onclick = run(async () => {
      const t = $('#pairOut', v).textContent;
      try { await navigator.clipboard.writeText(t); } catch { const ta = document.createElement('textarea'); ta.value = t; document.body.append(ta); ta.select(); document.execCommand('copy'); ta.remove(); }
      toast('Disalin. Tempel ke chat bot (nomor owner).');
    });
    $('#payPreset', v).onclick = run(async () => {
      if (!confirm('Isi otomatis semua alamat & nama field sesuai dokumentasi AustinPay? API key kamu tetap aman.')) return;
      await api('/payment-preset', 'POST', {}); toast('Pengaturan AustinPay dipasang'); shell();
    });
    $('#payIp', v).onclick = run(async () => {
      const o = $('#payIpOut', v); o.textContent = 'Mengecek…';
      const r = await api('/egress-ip');
      o.innerHTML = r.ip ? `IP server ini: <code class="k">${esc(r.ip)}</code><br>Daftarkan di <b>austinx.cloud/profile</b> &gt; Whitelist IP, lalu tes lagi.` : 'Gagal mengecek IP (server tidak bisa keluar ke internet?).';
    });
    $('#payTest', v).onclick = run(async () => {
      const b = $('#payTest', v), out = $('#payOut', v);
      b.disabled = true; out.hidden = false; out.style.borderColor = ''; out.textContent = 'Menguji…';
      try {
        const r = await api('/payment-test', 'POST', {});
        const L = [`${r.good ? '✓' : '✗'} ${r.hint}`];
        if (r.url) L.push(`\n${r.method} ${r.url}`);
        if (r.status) L.push(`Status HTTP: ${r.status}`);
        if (r.error) L.push(`Error: ${r.error}`);
        if (r.found) L.push('\nData yang ditemukan:\n' + Object.entries(r.found).map(([k, x]) => `  ${k}: ${x ?? '-'}`).join('\n'));
        if (r.body) L.push('\nIsi respon:\n' + r.body);
        out.textContent = L.join('\n'); out.style.borderColor = r.good ? '#14502a' : '#5a1612';
      } finally { b.disabled = false; }
    });
    $('#bf', v).onsubmit = run(async (e) => { e.preventDefault(); const f = e.target; await api('/settings', 'PUT', { botApiKey: val(f, 'botApiKey'), botUrl: val(f, 'botUrl'), ownerPhone: val(f, 'ownerPhone') }); toast('Tersimpan'); shell(); });
    $('#pf', v).onsubmit = run(async (e) => {
      e.preventDefault(); const f = e.target;
      const pay = { apikey: val(f, 'apikey'), apiSecret: val(f, 'apiSecret'), map: {} };
      ['baseUrl', 'method', 'statusMethod', 'createPath', 'statusPath', 'authMode', 'keyField', 'bodyFormat', 'amountField', 'refField', 'paidValues', 'expiredValues'].forEach((k) => pay[k] = val(f, k));
      ['trxId', 'qrImage', 'qrString', 'payUrl', 'expired', 'payAmount', 'status'].forEach((k) => pay.map[k] = val(f, 'map_' + k));
      await api('/settings', 'PUT', { payment: pay }); toast('Tersimpan'); shell();
    });
  },

  async info() {
    const s = S;
    const v = view(`<h2>Informasi</h2><form class="card" id="if" style="margin-top:16px">
      <label style="margin-top:0">WhatsApp (nomor atau link)</label><input name="wa" value="${esc(s.whatsapp)}" placeholder="6281234567890">
      <label>Telegram (@username atau link)</label><input name="tg" value="${esc(s.telegram)}" placeholder="@username">
      <h3 style="margin-top:20px">Notifikasi Saluran WhatsApp</h3>
      <label>ID / JID saluran</label><input name="channelId" value="${esc(s.channelId || '')}" placeholder="contoh: 1234567890@newsletter atau ID saluran">
      <label>Link saluran (opsional)</label><input name="channelLink" value="${esc(s.channelLink || '')}" placeholder="https://whatsapp.com/channel/...">
      <label>Alamat website publik untuk kartu transaksi</label><input name="publicUrl" value="${esc(s.publicUrl || location.origin)}" placeholder="https://domainkamu.com">
      <p class="hint">Set ID/JID saluran sebagai tujuan kirim. Kartu transaksi memakai <b>nama + logo website</b> yang sama dari pengaturan website.</p>
      <label>Catatan jam layanan (opsional)</label><textarea name="note" maxlength="200" placeholder="Contoh: Admin online 09.00 - 21.00 WIB">${esc(s.contactNote)}</textarea>
      <p class="hint">Semua ini tampil di bagian <b>Kontak</b> di toko.</p><button class="btn sm" style="margin-top:14px" type="submit">Simpan</button></form>`);
    $('#if', v).onsubmit = run(async (e) => { e.preventDefault(); await api('/settings', 'PUT', { whatsapp: val(e.target, 'wa'), telegram: val(e.target, 'tg'), channelId: val(e.target, 'channelId'), channelLink: val(e.target, 'channelLink'), publicUrl: val(e.target, 'publicUrl'), contactNote: val(e.target, 'note') }); toast('Tersimpan'); shell(); });
  },

  async database() {
    const s = S.github || {};
    const v = view(`<h2>Database GitHub</h2>
      <div class="card" style="margin-top:16px">
        <h3>Koneksi penyimpanan GitHub</h3>
        <p class="hint">Masukkan detail repository Private yang akan dipakai sebagai penyimpanan database. Token hanya digunakan untuk tes koneksi pada sesi ini dan tidak disimpan ke file database.</p>
        <form id="ghForm">
          <label>GitHub Token (Fine-grained)</label>
          <input id="ghToken" type="password" autocomplete="off" placeholder="github_pat_…" required>
          <p class="hint">Beri akses hanya ke repository tujuan dengan izin Contents: Read and write. Jangan gunakan token yang punya akses ke semua repository.</p>
          <div class="row2">
            <div><label>Owner / username GitHub</label><input id="ghOwner" value="${esc(s.owner || '')}" placeholder="username" required></div>
            <div><label>Nama repository</label><input id="ghRepo" value="${esc(s.repo || '')}" placeholder="ipungg-store-data" required></div>
            <div><label>Branch</label><input id="ghBranch" value="${esc(s.branch || 'main')}" required></div>
            <div><label>Path file JSON</label><input id="ghPath" value="${esc(s.path || 'data/db.json')}" required></div>
          </div>
          <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:14px">
            <button class="btn" id="ghTest" type="button">Tes koneksi GitHub</button>
            <button class="btn ghost" id="ghSave" type="submit">Simpan detail repository</button>
          </div>
          <pre class="pre" id="ghOut" hidden style="margin-top:12px"></pre>
        </form>
      </div>
      <div class="card" style="margin-top:14px">
        <h3>Penting soal token</h3>
        <p class="hint">Demi keamanan, token tidak disimpan di data/db.json atau ditampilkan kembali setelah tes. Agar backend Vercel dapat memakai token secara permanen, token harus ditambahkan sebagai Environment Variable di Vercel (misalnya <code class="k">GH_TOKEN</code>). Integrasi database GitHub belum aktif hanya dengan menyimpan detail repository ini.</p>
      </div>`);
    const payload = () => ({ owner: $('#ghOwner', v).value.trim(), repo: $('#ghRepo', v).value.trim(), branch: $('#ghBranch', v).value.trim(), path: $('#ghPath', v).value.trim() });
    $('#ghForm', v).onsubmit = run(async (e) => {
      e.preventDefault();
      await api('/settings', 'PUT', { github: payload() });
      toast('Detail repository disimpan'); shell();
    });
    $('#ghTest', v).onclick = run(async () => {
      const out = $('#ghOut', v); out.hidden = false; out.textContent = 'Menguji koneksi…';
      const r = await api('/github-test', 'POST', { ...payload(), token: $('#ghToken', v).value.trim() });
      out.textContent = r.message || 'Koneksi berhasil';
      toast('Koneksi GitHub berhasil');
    });
  },

  async diagnosa() {
    const v = view(`<h2>Diagnosa</h2><p style="margin:6px 0 16px">Menguji koneksi bot dan pembayaran sekaligus. Kirim hasilnya (screenshot atau salin) kalau butuh bantuan. API key tidak ikut ditampilkan.</p>
      <div class="card"><button class="btn" id="dgRun" type="button" style="margin-top:0">Jalankan diagnosa</button>
        <label style="display:flex;gap:8px;align-items:center"><input type="checkbox" id="dgPay" style="width:auto" checked> Ikut tes pembayaran (membuat 1 QR uji yang kedaluwarsa sendiri)</label>
        <pre class="pre" id="dgOut" hidden></pre>
        <button class="btn ghost sm" id="dgCopy" type="button" style="margin-top:12px" hidden>Salin laporan</button></div>`);
    const out = $('#dgOut', v), copyBtn = $('#dgCopy', v);
    const report = (r) => {
      const b = r.bot, p = r.payment, ok1 = (x) => (x ? '✓' : '✗');
      const L = [`LAPORAN DIAGNOSA — ${S.siteName}`, `Waktu: ${dt(r.time)}`, `Versi server web: ${r.version} (Node ${r.node})`, '',
        '[BOT]', `Mode: ${b.mode}`, `BOT_URL: ${b.url || '(kosong = satu server dengan bot)'}`, `API key bot: ${b.keyFilled ? 'terisi' : 'BELUM diisi'}`,
        `Hasil: ${ok1(b.state === 'online')} ${b.state}`, `Pesan: ${b.msg}`, `Versi server bot: ${b.version || '(tidak dikirim, kemungkinan file server bot lama)'}`, '',
        '[PEMBAYARAN]', `IP keluar server web: ${r.egressIp || '(gagal dicek)'}  <- daftarkan di AustinPay > Profil > Whitelist IP`, `Base URL: ${p.baseUrl}`, `Buat transaksi: ${p.method} ${p.createPath}`, `Cek status: ${p.statusPath}`, `API key payment: ${p.keyFilled ? 'terisi' : 'BELUM diisi'}`,
        `Error terakhir: ${p.lastError ? p.lastError.msg : '-'}`];
      if (p.test) {
        const t = p.test;
        L.push(`Tes buat transaksi: ${ok1(t.good)} ${t.hint}`);
        if (t.status) L.push(`Status HTTP: ${t.status}`);
        if (t.error) L.push(`Error: ${t.error}`);
        if (t.found) L.push('Data ditemukan: ' + Object.entries(t.found).map(([k, x]) => `${k}=${x ?? '-'}`).join(', '));
        if (t.body) L.push('Isi respon:', t.body);
      }
      return L.join('\n');
    };
    const go = run(async () => {
      const b = $('#dgRun', v); b.disabled = true; out.hidden = false; out.textContent = 'Menguji… (bisa sampai 30 detik)'; copyBtn.hidden = true;
      try { out.textContent = report(await api('/diagnosa' + ($('#dgPay', v).checked ? '?pay=1' : ''))); copyBtn.hidden = false; }
      finally { b.disabled = false; }
    });
    $('#dgRun', v).onclick = go;
    copyBtn.onclick = run(async () => {
      const t = out.textContent;
      try { await navigator.clipboard.writeText(t); }
      catch { const ta = document.createElement('textarea'); ta.value = t; document.body.append(ta); ta.select(); document.execCommand('copy'); ta.remove(); }
      toast('Laporan disalin. Tempel di chat.');
    });
  },

  async akun() {
    const v = view(`<h2>Akun admin</h2><form class="card" id="af" style="margin-top:16px">
      <label style="margin-top:0">Password saat ini</label><input name="cur" type="password" required autocomplete="current-password">
      <label>Username baru (opsional)</label><input name="usr" autocomplete="username">
      <label>Password baru (min. 8 karakter)</label><input name="pw" type="password" minlength="8" required autocomplete="new-password">
      <button class="btn sm" style="margin-top:16px" type="submit">Ganti &amp; keluar</button></form>`);
    $('#af', v).onsubmit = run(async (e) => { e.preventDefault(); const f = e.target; await api('/account', 'POST', { current: val(f, 'cur'), username: val(f, 'usr'), password: val(f, 'pw') }); toast('Diganti, silakan masuk lagi'); loginView(); });
  },
};

shell().catch(() => loginView());
