const $ = (s) => document.querySelector(s);
const rp = (n) => 'Rp' + Number(n).toLocaleString('id-ID');
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const q = new URLSearchParams(location.search);
const id = q.get('id'), t = q.get('t');
const app = $('#app');
let timer = null;

fetch('/api/public').then((r) => r.json()).then((j) => { if (j.ok) $('#siteName').textContent = j.site.name; }).catch(() => {});

const fmt = (ms) => { const s = Math.max(0, Math.floor(ms / 1000)); return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0'); };
const when = (ms) => new Date(ms).toLocaleString('id-ID', { dateStyle: 'medium', timeStyle: 'short' });

function render(o) {
  const paid = o.status === 'paid', exp = o.status === 'expired', cancelled = o.status === 'cancelled';
  let h = '';
  if (paid) {
    h += `<div class="status paid"><span class="pulse"></span><div><b>Pembayaran diterima</b><br><small>${
      o.fulfil === 'done' ? (o.type === 'sewa' ? 'Bot sudah diproses ke grupmu.' : 'Produk siap diunduh di halaman web.')
      : o.fulfil === 'error' ? 'Pembayaran aman. Admin akan memproses manual, tidak perlu bayar lagi.'
      : 'Sedang memproses pesananmu…'}</small></div></div>`;
  } else if (cancelled) {
    h += `<div class="status expired"><span class="pulse"></span><div><b>Pesanan dibatalkan</b><br><small>Pesanan ini sudah dibatalkan dan tidak bisa dibayar lagi.</small></div></div>`;
  } else if (exp) {
    h += `<div class="status expired"><span class="pulse"></span><div><b>Waktu pembayaran habis</b><br><small>Buat pesanan baru untuk melanjutkan.</small></div></div>`;
  } else {
    h += `<div class="status"><span class="pulse"></span><div><b>Menunggu pembayaran</b><br><small>Halaman ini memeriksa otomatis.</small></div></div>`;
  }

  h += `<div class="card"><div class="rows">
    <div><span>Pesanan</span><b>${esc(o.itemName)}</b></div>
    <div><span>ID</span><b>${esc(o.id)}</b></div></div>`;

  if (!paid && !exp) {
    const payNow = o.payAmount || o.amount, extra = payNow - o.amount;
    h += `<p class="big" style="margin-top:16px">${rp(payNow)}</p>
      <p class="hint" style="text-align:center">${extra > 0 ? `Harga ${rp(o.amount)} + kode unik ${rp(extra)}. ` : ''}Bayar <b>tepat</b> sesuai nominal ini.</p>
      <p class="timer">Bayar dalam <b id="cd">--:--</b></p>`;
    if (o.qrImage) h += `<div class="qr"><img src="${esc(o.qrImage)}" alt="QRIS"></div>`;
    if (o.payUrl) h += `<a class="btn" href="${esc(o.payUrl)}" target="_blank" rel="noopener">Buka halaman bayar</a>`;
    if (!o.qrImage && !o.payUrl && o.qrString) h += `<label>Kode QRIS</label><textarea readonly>${esc(o.qrString)}</textarea>`;
    h += `<div class="pay-actions"><button class="btn check" type="button" id="checkBtn">✓ Cek Transaksi</button><button class="btn cancel" type="button" id="cancelBtn">✕ Batalkan Pesanan</button></div>`;
    h += `<p class="hint" style="text-align:center;margin-top:12px">Jumlah harus sama persis. Setelah bayar, tekan <b>Cek Transaksi</b> untuk cek sekarang.</p>`;
  }
  if (paid && o.fulfil === 'done' && o.result) {
    if (o.type === 'sewa') {
      h += `<div class="rows" style="margin-top:14px"><div><span>Grup</span><b>${esc(o.result.groupName)}</b></div>
        <div><span>Berakhir</span><b>${when(o.result.expired)}</b></div></div>
        ${o.result.joinStatus === 'pending' ? '<p class="hint">Bot belum masuk. Jika grup memakai persetujuan admin, setujui permintaan dari bot.</p>' : ''}`;
    } else if (o.result.url) {
      h += `<a class="btn" href="${esc(o.result.url)}" target="_blank" rel="noopener">Download sekarang</a>` +
        (o.result.note ? `<p class="hint" style="margin-top:12px">${esc(o.result.note)}</p>` : '');
    }
  }
  h += `</div><p class="hint" style="text-align:center;margin-top:16px"><a href="/">Kembali ke toko</a></p>`;
  app.innerHTML = h;

  const checkBtn = $('#checkBtn');
  if (checkBtn) checkBtn.onclick = async () => {
    checkBtn.disabled = true; checkBtn.textContent = 'Mengecek…';
    try { await poll(true); } finally { if (checkBtn) { checkBtn.disabled = false; checkBtn.textContent = 'Cek Transaksi'; } }
  };
  const cancelBtn = $('#cancelBtn');
  if (cancelBtn) cancelBtn.onclick = async () => {
    if (!confirm('Batalkan pesanan ini? Pesanan yang sudah dibayar tidak dapat dibatalkan.')) return;
    cancelBtn.disabled = true; cancelBtn.textContent = 'Membatalkan…';
    try {
      const r = await fetch(`/api/order/${encodeURIComponent(id)}/cancel?t=${encodeURIComponent(t)}`, { method: 'POST' });
      const j = await r.json();
      if (!j.ok) throw new Error(j.error || 'Gagal membatalkan pesanan');
      await poll(true);
    } catch (e) { alert(e.message); if (cancelBtn) { cancelBtn.disabled = false; cancelBtn.textContent = 'Batalkan Pesanan'; } }
  };

  if (!paid && !exp && !cancelled) {
    const tick = () => { const el = $('#cd'); if (el) el.textContent = fmt(o.expireAt - Date.now()); };
    tick(); clearInterval(timer); timer = setInterval(tick, 1000);
  } else clearInterval(timer);
}

let busy = false;
async function poll(force = false) {
  if (busy) return; busy = true;
  try {
    const r = await fetch(`/api/order/${encodeURIComponent(id)}?t=${encodeURIComponent(t)}${force ? '&force=1' : ''}&_v=20261007`, { cache: 'no-store' });
    const j = await r.json();
    if (!j.ok) { app.innerHTML = `<div class="status expired"><span class="pulse"></span><div><b>${esc(j.error)}</b></div></div><p class="hint"><a href="/">Kembali ke toko</a></p>`; return stop(); }
    const first = !app.dataset.sig;
    const sig = j.order.status + j.order.fulfil;
    if (first || app.dataset.sig !== sig) { app.dataset.sig = sig; render(j.order); }
    if (j.order.status === 'expired' || j.order.status === 'cancelled' || (j.order.status === 'paid' && j.order.fulfil !== 'waiting')) stop();
  } catch (e) { /* jaringan putus sebentar, coba lagi */ } finally { busy = false; }
}
let iv = null; const stop = () => clearInterval(iv);
if (!id || !t) app.innerHTML = '<p>Link pesanan tidak valid.</p>'; else { poll(); iv = setInterval(poll, 4000); }
